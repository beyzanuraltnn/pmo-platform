import { apiClient } from "../client";
import type { ApiResponse, LoginRequest, LoginResponse } from "../types";

export const authService = {
  async login(payload: LoginRequest) {
    const response = await apiClient.post<ApiResponse<LoginResponse>>("/api/auth/login", payload);
    return response.data.data;
  }
};
