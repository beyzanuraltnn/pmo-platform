import { apiClient } from "../client";
import type { ApiResponse, NotificationItem } from "../types";

export const notificationService = {
  async getNotifications() {
    const response = await apiClient.get<ApiResponse<NotificationItem[]>>("/api/notifications");
    return response.data.data;
  }
};
