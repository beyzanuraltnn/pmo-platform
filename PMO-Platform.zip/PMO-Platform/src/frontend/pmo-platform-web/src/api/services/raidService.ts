import { apiClient } from "../client";
import type {
  ApiResponse,
  CreateOrUpdateRaidItemRequest,
  GetRaidItemsParams,
  RaidDetail,
  RaidListItem,
  RaidSummary
} from "../types";

export const raidService = {
  async getProjectRaidItems(projectId: string, params?: GetRaidItemsParams) {
    const response = await apiClient.get<ApiResponse<RaidListItem[]>>(`/api/projects/${projectId}/raid`, {
      params
    });
    return response.data.data;
  },

  async getRaidSummary(projectId: string) {
    const response = await apiClient.get<ApiResponse<RaidSummary>>(`/api/projects/${projectId}/raid/summary`);
    return response.data.data;
  },

  async getRaidItem(id: string) {
    const response = await apiClient.get<ApiResponse<RaidDetail>>(`/api/raid/${id}`);
    return response.data.data;
  },

  async createRaidItem(projectId: string, payload: CreateOrUpdateRaidItemRequest) {
    const response = await apiClient.post<ApiResponse<RaidDetail>>(`/api/projects/${projectId}/raid`, payload);
    return response.data.data;
  },

  async updateRaidItem(id: string, payload: CreateOrUpdateRaidItemRequest) {
    const response = await apiClient.put<ApiResponse<RaidDetail>>(`/api/raid/${id}`, payload);
    return response.data.data;
  },

  async closeRaidItem(id: string, note?: string) {
    const response = await apiClient.put<ApiResponse<RaidDetail>>(`/api/raid/${id}/close`, { note });
    return response.data.data;
  }
};
