import { apiClient } from "../client";
import type { ApiResponse, CreateOrUpdateProjectRequest, DashboardSummary, ProjectDetail, ProjectListItem } from "../types";

export const projectService = {
  async getDashboardSummary() {
    const response = await apiClient.get<ApiResponse<DashboardSummary>>("/api/projects/dashboard-summary");
    return response.data.data;
  },

  async getProjects(status?: string) {
    const response = await apiClient.get<ApiResponse<ProjectListItem[]>>("/api/projects", {
      params: status ? { status } : undefined
    });

    return response.data.data;
  },

  async getProjectDetail(id: string) {
    const response = await apiClient.get<ApiResponse<ProjectDetail>>(`/api/projects/${id}`);
    return response.data.data;
  },

  async createProject(payload: CreateOrUpdateProjectRequest) {
    const response = await apiClient.post<ApiResponse<ProjectDetail>>("/api/projects", payload);
    return response.data.data;
  },

  async updateProject(id: string, payload: CreateOrUpdateProjectRequest) {
    const response = await apiClient.put<ApiResponse<ProjectDetail>>(`/api/projects/${id}`, payload);
    return response.data.data;
  },

  async getProjectSummary(id: string) {
    const response = await apiClient.get<ApiResponse<{ charterExists: boolean; latestGateStatus: string; notificationCount: number; projectId: string; projectName: string }>>(
      `/api/projects/${id}/summary`
    );
    return response.data.data;
  }
};
