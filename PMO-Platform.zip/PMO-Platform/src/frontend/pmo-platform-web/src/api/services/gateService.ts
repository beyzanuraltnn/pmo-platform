import { apiClient } from "../client";
import type { ApiResponse, EvidenceItem, GateDetail, GateListItem } from "../types";

export const gateService = {
  async getProjectGates(projectId: string) {
    const response = await apiClient.get<ApiResponse<GateListItem[]>>(`/api/projects/${projectId}/gates`);
    return response.data.data;
  },

  async getGateDetail(gateId: string) {
    const response = await apiClient.get<ApiResponse<GateDetail>>(`/api/gates/${gateId}`);
    return response.data.data;
  },

  async uploadEvidence(gateId: string, payload: { file: File; category: string; isRequired: boolean }) {
    const formData = new FormData();
    formData.append("file", payload.file);
    formData.append("category", payload.category);
    formData.append("isRequired", String(payload.isRequired));

    const response = await apiClient.post<ApiResponse<EvidenceItem>>(`/api/gates/${gateId}/evidences`, formData, {
      headers: {
        "Content-Type": "multipart/form-data"
      }
    });

    return response.data.data;
  },

  async deleteEvidence(gateId: string, evidenceId: string) {
    await apiClient.delete(`/api/gates/${gateId}/evidences/${evidenceId}`);
  },

  async submitGate(gateId: string) {
    const response = await apiClient.post<ApiResponse<GateDetail>>(`/api/gates/${gateId}/submit`);
    return response.data.data;
  },

  async approveGate(gateId: string, note?: string) {
    const response = await apiClient.post<ApiResponse<GateDetail>>(`/api/gates/${gateId}/approve`, { note });
    return response.data.data;
  },

  async rejectGate(gateId: string, note: string) {
    const response = await apiClient.post<ApiResponse<GateDetail>>(`/api/gates/${gateId}/reject`, { note });
    return response.data.data;
  }
};
