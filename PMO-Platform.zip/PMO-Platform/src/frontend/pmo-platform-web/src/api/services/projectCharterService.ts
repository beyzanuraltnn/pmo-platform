import { apiClient } from "../client";
import type { ApiResponse, CreateOrUpdateProjectCharterRequest, ProjectCharterDetail } from "../types";

export const projectCharterService = {
  async getProjectCharter(projectId: string) {
    const response = await apiClient.get<ApiResponse<ProjectCharterDetail>>(`/api/projects/${projectId}/charter`);
    return response.data.data;
  },

  async createProjectCharter(projectId: string, payload: CreateOrUpdateProjectCharterRequest) {
    const response = await apiClient.post<ApiResponse<ProjectCharterDetail>>(`/api/projects/${projectId}/charter`, payload);
    return response.data.data;
  },

  async updateProjectCharter(projectId: string, payload: CreateOrUpdateProjectCharterRequest) {
    const response = await apiClient.put<ApiResponse<ProjectCharterDetail>>(`/api/projects/${projectId}/charter`, payload);
    return response.data.data;
  }
};
