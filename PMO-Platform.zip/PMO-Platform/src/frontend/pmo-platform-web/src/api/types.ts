export type ApiResponse<T> = {
  success: boolean;
  message: string;
  errors?: unknown;
  data: T;
};

export type LoginRequest = {
  email: string;
  password: string;
};

export type LoginResponse = {
  token: string;
  expiresAt?: string;
  user?: {
    id?: string;
    fullName?: string;
    email?: string;
    role?: string;
  };
};

export type DashboardSummary = {
  summaryCards: Array<{
    label: string;
    value: string | number;
    note: string;
    tone: "blue" | "green" | "yellow" | "red";
  }>;
  activeProjects: Array<{
    id?: string;
    name: string;
    type: string;
    projectManager: string;
    stage: string;
    ragStatus: "green" | "yellow" | "red";
    goLiveDateText: string;
    riskLevel: string;
  }>;
  weeklyGoLives: Array<{
    projectName: string;
    dateText: string;
    statusText: string;
    note: string;
  }>;
  delayedMilestones: Array<{
    projectName: string;
    milestoneName: string;
    plannedDateText: string;
    newTargetDateText: string;
  }>;
  criticalRisks: Array<{
    projectName: string;
    riskText: string;
    impactLevel: string;
    actionText: string;
  }>;
  actionItems: Array<{
    title: string;
    body: string;
    buttonText: string;
    tone: "red" | "yellow";
  }>;
};

export type ProjectListItem = {
  id?: string;
  name: string;
  code: string;
  type: string;
  description: string;
  businessOwner: string;
  projectManagerId?: string;
  projectManager: string;
  sponsor: string;
  priority?: string;
  stage?: string;
  ragStatus?: "green" | "yellow" | "red";
  plannedStartDateText?: string;
  plannedEndDateText?: string;
  expectedGoLiveDateText?: string;
  actualGoLiveDateText?: string;
  budgetText?: string;
  department: string;
  notes: string;
  goLiveDateText?: string;
  riskLevel?: string;
  stageGateStatus?: string;
  plannedStartText?: string;
  expectedGoLiveText?: string;
  note?: string;
  scheduleVarianceText?: string;
  uatRateText?: string;
  status: string;
};

export type ProjectDetail = ProjectListItem & {
  plannedStartDate?: string | null;
  plannedEndDate?: string | null;
  expectedGoLiveDate?: string | null;
  actualGoLiveDate?: string | null;
  canEdit: boolean;
  charterExists: boolean;
};

export type CreateOrUpdateProjectRequest = {
  name: string;
  code: string;
  type: string;
  status: string;
  description: string;
  businessOwner: string;
  projectManagerId: string;
  sponsor: string;
  priority: string;
  ragStatus: string;
  stage: string;
  plannedStartDate?: string | null;
  plannedEndDate?: string | null;
  expectedGoLiveDate?: string | null;
  actualGoLiveDate?: string | null;
  budget?: number | null;
  department: string;
  notes: string;
};

export type ProjectCharterDetail = {
  id?: string | null;
  projectId: string;
  purpose: string;
  objectives: string;
  scope: string;
  outOfScope: string;
  successCriteria: string;
  risksAndAssumptions: string;
  dependencies: string;
  stakeholders: string;
  timelineSummary: string;
  budgetSummary: string;
  approvalNotes: string;
  version: number;
  lastReviewedAtText?: string | null;
  exists: boolean;
  canEdit: boolean;
};

export type CreateOrUpdateProjectCharterRequest = {
  purpose: string;
  objectives: string;
  scope: string;
  outOfScope: string;
  successCriteria: string;
  risksAndAssumptions: string;
  dependencies: string;
  stakeholders: string;
  timelineSummary: string;
  budgetSummary: string;
  approvalNotes: string;
};

export type RaidListItem = {
  id: string;
  type: string;
  title: string;
  status: string;
  priority?: string | null;
  impact?: string | null;
  owner: string;
  dueDateText: string;
  note: string;
  badgeTone: "red" | "yellow" | "blue" | "purple" | "gray";
};

export type RaidDetail = {
  id: string;
  projectId: string;
  type: string;
  title: string;
  description: string;
  status: string;
  priority?: string | null;
  impact?: string | null;
  owner: string;
  actionPlan: string;
  dueDate?: string | null;
  dueDateText: string;
  resolvedDate?: string | null;
  resolvedDateText?: string | null;
  note: string;
  canEdit: boolean;
  canClose: boolean;
};

export type RaidSummary = {
  totalCount: number;
  openCount: number;
  criticalRiskCount: number;
  overdueCount: number;
  riskCount: number;
  issueCount: number;
  assumptionCount: number;
  dependencyCount: number;
};

export type GetRaidItemsParams = {
  type?: string;
  status?: string;
  priority?: string;
  search?: string;
};

export type CreateOrUpdateRaidItemRequest = {
  type: string;
  title: string;
  description: string;
  status: string;
  priority?: string | null;
  impact?: string | null;
  owner: string;
  actionPlan: string;
  dueDate?: string | null;
  note: string;
};

export type NotificationItem = {
  id?: string;
  title: string;
  body: string;
  time: string;
  unread: boolean;
};

export type GateListItem = {
  id: string;
  gateNo: number;
  name: string;
  status: string;
  dueDateText: string;
  uploadedEvidenceCount: number;
  requiredEvidenceCount: number;
  pendingApprovalCount: number;
  owner: string;
  note: string;
};

export type EvidenceItem = {
  id: string;
  fileName: string;
  uploadedBy: string;
  uploadedAtText: string;
  category: string;
  isRequired: boolean;
};

export type ApprovalItem = {
  id: string;
  approverName: string;
  role: string;
  status: string;
  decisionDateText?: string | null;
  note?: string | null;
};

export type GateDetail = {
  id: string;
  projectId: string;
  gateNo: number;
  name: string;
  status: string;
  description: string;
  openDateText: string;
  dueDateText: string;
  closedDateText?: string | null;
  requiredEvidenceCount: number;
  uploadedEvidenceCount: number;
  canSubmit: boolean;
  canApprove: boolean;
  canReject: boolean;
  evidences: EvidenceItem[];
  approvals: ApprovalItem[];
};
