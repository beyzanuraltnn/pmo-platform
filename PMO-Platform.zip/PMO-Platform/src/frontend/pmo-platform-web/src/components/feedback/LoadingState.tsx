type LoadingStateProps = {
  message?: string;
};

export function LoadingState({ message = "Veriler yükleniyor..." }: LoadingStateProps) {
  return (
    <div className="empty">
      <div className="loader" />
      <div className="empty-text">{message}</div>
      <div className="empty-sub">Lütfen bekleyin.</div>
    </div>
  );
}
