type EmptyStateProps = {
  title?: string;
  subtitle?: string;
};

export function EmptyState({
  title = "Gösterilecek veri bulunamadı",
  subtitle = "Seçili filtreler veya mevcut kayıt durumu nedeniyle içerik boş olabilir."
}: EmptyStateProps) {
  return (
    <div className="empty">
      <div className="empty-icon">∅</div>
      <div className="empty-text">{title}</div>
      <div className="empty-sub">{subtitle}</div>
    </div>
  );
}
