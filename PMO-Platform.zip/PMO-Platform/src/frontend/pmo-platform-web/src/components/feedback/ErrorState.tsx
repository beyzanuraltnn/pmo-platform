type ErrorStateProps = {
  message?: string;
  onRetry?: () => void;
};

export function ErrorState({ message = "Veri alınırken bir sorun oluştu.", onRetry }: ErrorStateProps) {
  return (
    <div className="empty">
      <div className="empty-icon">⚠</div>
      <div className="empty-text">{message}</div>
      <div className="empty-sub">Bağlantıyı kontrol edip tekrar deneyin.</div>
      {onRetry ? (
        <button className="btn btn-secondary" style={{ marginTop: 12 }} type="button" onClick={onRetry}>
          Tekrar Dene
        </button>
      ) : null}
    </div>
  );
}
