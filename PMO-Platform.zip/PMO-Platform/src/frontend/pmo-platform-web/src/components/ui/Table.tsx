import type { ReactNode } from "react";

type TableProps = {
  columns: string[];
  rows: ReactNode[][];
};

export function Table({ columns, rows }: TableProps) {
  return (
    <table className="tbl">
      <thead>
        <tr>
          {columns.map((column) => (
            <th key={column}>{column}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row, rowIndex) => (
          <tr key={rowIndex}>
            {row.map((cell, cellIndex) => (
              <td key={`${rowIndex}-${cellIndex}`}>{cell}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
