import { BellIcon } from "../icons/NavIcons";

type TopbarProps = {
  title: string;
  meta: string;
  unreadCount: number;
  onToggleNotifications: () => void;
  onLogout: () => void;
};

export function Topbar({ title, meta, unreadCount, onToggleNotifications, onLogout }: TopbarProps) {
  return (
    <div className="topbar">
      <div className="topbar-title">{title}</div>
      <div className="topbar-meta">{meta}</div>
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <button className="btn btn-secondary btn-sm" type="button">
          📧 Raporla
        </button>
        <button className="btn btn-secondary btn-sm" type="button" onClick={onLogout}>
          Çıkış
        </button>
        <button className="notif-btn" type="button" title="Bildirimler" onClick={onToggleNotifications}>
          <BellIcon />
          {unreadCount > 0 ? <div className="notif-count">{unreadCount > 9 ? "9+" : unreadCount}</div> : null}
        </button>
      </div>
    </div>
  );
}
