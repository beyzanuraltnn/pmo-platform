type ToastProps = {
  message: string;
  tone?: "default" | "success" | "warning";
  open: boolean;
};

export function Toast({ message, tone = "default", open }: ToastProps) {
  const className = ["toast", open ? "show" : "", tone === "default" ? "" : tone].filter(Boolean).join(" ");

  return <div className={className}>{message}</div>;
}
