import type { ReactNode } from "react";

type ModalProps = {
  open: boolean;
  title: string;
  children: ReactNode;
  size?: "default" | "sm";
};

export function Modal({ open, title, children, size = "default" }: ModalProps) {
  if (!open) {
    return null;
  }

  return (
    <div className="modal-backdrop">
      <div className={`modal ${size === "sm" ? "modal-sm" : ""}`.trim()}>
        <div className="modal-header">
          <div className="modal-title">{title}</div>
          <button className="modal-close" type="button">
            ✕
          </button>
        </div>
        <div className="modal-body">{children}</div>
        <div className="modal-footer">
          <button className="btn btn-secondary" type="button">
            İptal
          </button>
          <button className="btn btn-primary" type="button">
            Kaydet
          </button>
        </div>
      </div>
    </div>
  );
}
