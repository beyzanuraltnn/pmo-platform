import { NavLink, useLocation } from "react-router-dom";
import { useAuth } from "../../auth/AuthContext";
import { navigationGroups } from "../../data/demo";

export function Sidebar() {
  const location = useLocation();
  const { user } = useAuth();
  const initials = (user?.fullName ?? "Ahmet Kaya")
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");

  return (
    <aside className="sidebar">
      <div className="sidebar-top">
        <div className="logo">
          <div className="logo-icon">P</div>
          PMO <span>Platform</span>
        </div>
        <div className="logo-sub">v2.0 · PAROLAPARA</div>
      </div>

      <nav className="nav">
        {navigationGroups.map((group) => (
          <div className="nav-group" key={group.label}>
            <div className="nav-label">{group.label}</div>
            {group.items.map((item) => {
              const Icon = item.icon;
              const isDynamicMatch =
                (item.path === "/charter" && /^\/projects\/[^/]+\/charter$/.test(location.pathname)) ||
                (item.path === "/raid" && /^\/projects\/[^/]+\/raid$/.test(location.pathname));

              return (
                <NavLink key={item.path} to={item.path} className={({ isActive }) => `nav-item${isActive || isDynamicMatch ? " active" : ""}`}>
                  <Icon />
                  {item.label}
                  {item.badge ? <span className={`nav-badge nb-${item.badge.tone}`}>{item.badge.text}</span> : null}
                </NavLink>
              );
            })}
          </div>
        ))}
      </nav>

      <div className="sidebar-user">
        <div className="user-av">{initials || "AK"}</div>
        <div>
          <div className="user-name">{user?.fullName ?? user?.email ?? "Ahmet Kaya"}</div>
          <div className="user-role">{user?.role ?? "PMO_ADMIN"}</div>
        </div>
      </div>
    </aside>
  );
}
