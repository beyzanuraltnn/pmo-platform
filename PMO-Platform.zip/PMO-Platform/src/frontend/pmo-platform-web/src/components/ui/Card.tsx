import type { ReactNode } from "react";

type CardProps = {
  title?: ReactNode;
  meta?: ReactNode;
  bodyClassName?: "card-body" | "card-body-0";
  children: ReactNode;
};

export function Card({ title, meta, bodyClassName = "card-body", children }: CardProps) {
  return (
    <div className="card">
      {(title || meta) && (
        <div className="card-header">
          <div className="card-title">{title}</div>
          {meta ? <div className="card-meta">{meta}</div> : null}
        </div>
      )}
      <div className={bodyClassName}>{children}</div>
    </div>
  );
}
