type StatCardProps = {
  label: string;
  value: string;
  note: string;
  tone: "blue" | "green" | "yellow" | "red";
};

export function StatCard({ label, value, note, tone }: StatCardProps) {
  return (
    <div className={`stat-card ${tone}`}>
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      <div className="stat-note">{note}</div>
    </div>
  );
}
