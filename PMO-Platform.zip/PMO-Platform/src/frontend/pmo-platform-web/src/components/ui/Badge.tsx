import type { ReactNode } from "react";

type BadgeTone = "green" | "yellow" | "red" | "blue" | "gray" | "purple";

type BadgeProps = {
  children: ReactNode;
  tone: BadgeTone;
};

export function Badge({ children, tone }: BadgeProps) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}
