import type { ModulePageData } from "../data/demo";
import { Card } from "../components/ui/Card";
import { PageHeader } from "../components/ui/PageHeader";
import { Table } from "../components/ui/Table";

type ModulePageProps = {
  page: ModulePageData;
};

export function ModulePage({ page }: ModulePageProps) {
  return (
    <div className="placeholder-stack">
      <PageHeader title={page.title} subtitle={page.subtitle} actions={page.action} />

      {page.alert ? (
        <div className={page.alert.className}>
          <span className="alert-icon">{page.alert.icon}</span>
          <span>{page.alert.text}</span>
        </div>
      ) : null}

      <Card title={page.cardTitle} meta={page.cardMeta} bodyClassName="card-body-0">
        <Table columns={page.columns} rows={page.rows} />
      </Card>

      <div className="placeholder-row">
        <Card title="Statik Layout Notu">
          <div className="empty">
            <div className="empty-icon">🧩</div>
            <div className="empty-text">Bu sayfada yalnızca iskelet oluşturuldu</div>
            <div className="empty-sub">Formlar, modal akışları ve veri etkileşimleri sonraki adımda eklenecek.</div>
          </div>
        </Card>

        <Card title="Referans Koruması">
          <div className="empty">
            <div className="empty-icon">🎯</div>
            <div className="empty-text">Sidebar, topbar, kart, tablo ve buton dili korunuyor</div>
            <div className="empty-sub">Bu aşamada amaç HTML referansını React bileşenlerine taşımak.</div>
          </div>
        </Card>
      </div>
    </div>
  );
}
