import { useCallback, useEffect, useMemo, useState } from "react";
import { AxiosError } from "axios";
import { useNavigate, useParams } from "react-router-dom";
import { projectCharterService } from "../../api/services/projectCharterService";
import { projectService } from "../../api/services/projectService";
import type { CreateOrUpdateProjectCharterRequest, ProjectCharterDetail, ProjectDetail, ProjectListItem } from "../../api/types";
import { EmptyState } from "../../components/feedback/EmptyState";
import { ErrorState } from "../../components/feedback/ErrorState";
import { LoadingState } from "../../components/feedback/LoadingState";
import { Card } from "../../components/ui/Card";
import { PageHeader } from "../../components/ui/PageHeader";
import { Toast } from "../../components/ui/Toast";

const emptyCharter: CreateOrUpdateProjectCharterRequest = {
  purpose: "",
  objectives: "",
  scope: "",
  outOfScope: "",
  successCriteria: "",
  risksAndAssumptions: "",
  dependencies: "",
  stakeholders: "",
  timelineSummary: "",
  budgetSummary: "",
  approvalNotes: ""
};

function getErrorMessage(error: unknown, fallback: string) {
  if (error instanceof AxiosError) {
    return (error.response?.data as { message?: string } | undefined)?.message ?? fallback;
  }

  return fallback;
}

export function ProjectCharterPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [projects, setProjects] = useState<ProjectListItem[]>([]);
  const [projectDetail, setProjectDetail] = useState<ProjectDetail | null>(null);
  const [charter, setCharter] = useState<ProjectCharterDetail | null>(null);
  const [form, setForm] = useState<CreateOrUpdateProjectCharterRequest>(emptyCharter);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<{ open: boolean; message: string; tone: "default" | "success" | "warning" }>({
    open: false,
    message: "",
    tone: "default"
  });

  useEffect(() => {
    if (!toast.open) return undefined;
    const timer = window.setTimeout(() => setToast((current) => ({ ...current, open: false })), 2600);
    return () => window.clearTimeout(timer);
  }, [toast.open]);

  const loadProjects = useCallback(async () => {
    const data = await projectService.getProjects();
    setProjects(data);
    return data;
  }, []);

  const loadPage = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const projectList = await loadProjects();
      const projectId = id ?? projectList[0]?.id;

      if (!projectId) {
        setProjectDetail(null);
        setCharter(null);
        setLoading(false);
        return;
      }

      if (!id && projectId) {
        navigate(`/projects/${projectId}/charter`, { replace: true });
      }

      const [detail, charterDetail] = await Promise.all([projectService.getProjectDetail(projectId), projectCharterService.getProjectCharter(projectId)]);
      setProjectDetail(detail);
      setCharter(charterDetail);
      setEditing(false);
      setForm({
        purpose: charterDetail.purpose ?? "",
        objectives: charterDetail.objectives ?? "",
        scope: charterDetail.scope ?? "",
        outOfScope: charterDetail.outOfScope ?? "",
        successCriteria: charterDetail.successCriteria ?? "",
        risksAndAssumptions: charterDetail.risksAndAssumptions ?? "",
        dependencies: charterDetail.dependencies ?? "",
        stakeholders: charterDetail.stakeholders ?? "",
        timelineSummary: charterDetail.timelineSummary ?? "",
        budgetSummary: charterDetail.budgetSummary ?? "",
        approvalNotes: charterDetail.approvalNotes ?? ""
      });
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Charter ekranı yüklenemedi."));
    } finally {
      setLoading(false);
    }
  }, [id, loadProjects, navigate]);

  useEffect(() => {
    void loadPage();
  }, [loadPage]);

  const charterSections = useMemo(() => {
    if (!charter?.exists) return [];

    return [
      { title: "Amaç", value: charter.purpose },
      { title: "Hedefler", value: charter.objectives },
      { title: "Scope", value: charter.scope },
      { title: "Out Of Scope", value: charter.outOfScope },
      { title: "Başarı Kriterleri", value: charter.successCriteria },
      { title: "Riskler ve Varsayımlar", value: charter.risksAndAssumptions },
      { title: "Bağımlılıklar", value: charter.dependencies },
      { title: "Paydaşlar", value: charter.stakeholders },
      { title: "Takvim Özeti", value: charter.timelineSummary },
      { title: "Bütçe Özeti", value: charter.budgetSummary },
      { title: "Onay Notları", value: charter.approvalNotes }
    ];
  }, [charter]);

  const handleSave = async () => {
    if (!projectDetail?.id) {
      return;
    }

    setSaving(true);
    setError(null);

    try {
      const response = charter?.exists
        ? await projectCharterService.updateProjectCharter(projectDetail.id, form)
        : await projectCharterService.createProjectCharter(projectDetail.id, form);

      setCharter(response);
      setProjectDetail((current) => (current ? { ...current, charterExists: true } : current));
      setEditing(false);
      setToast({ open: true, message: charter?.exists ? "Charter güncellendi." : "Charter oluşturuldu.", tone: "success" });
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Charter kaydedilemedi."));
      setToast({ open: true, message: "Charter kaydı başarısız.", tone: "warning" });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <LoadingState message="Project charter yükleniyor..." />;
  }

  if (error && !projectDetail) {
    return <ErrorState message={error} onRetry={() => void loadPage()} />;
  }

  if (!projectDetail) {
    return <EmptyState title="Proje bulunamadı" subtitle="Proje seçmeden charter görüntülenemez." />;
  }

  return (
    <div className="placeholder-stack">
      <PageHeader
        title="Project Charter"
        subtitle={`${projectDetail.name} · Charter onayı olmadan proje aktif olamaz.`}
        actions={
          <>
            <select className="inline-select" value={projectDetail.id} onChange={(event) => navigate(`/projects/${event.target.value}/charter`)}>
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </select>
            <button className="btn btn-secondary" type="button" onClick={() => navigate(`/projects/${projectDetail.id}`)}>
              Proje Detayı
            </button>
            <button className="btn btn-secondary" type="button" onClick={() => navigate(`/projects/${projectDetail.id}/raid`)}>
              RAID
            </button>
            {charter?.canEdit ? (
              <button className="btn btn-primary" type="button" onClick={() => setEditing((current) => !current)}>
                {editing ? "Formu Kapat" : charter.exists ? "Charter Düzenle" : "Charter Oluştur"}
              </button>
            ) : null}
          </>
        }
      />

      <div className="alert alert-warning">
        <span className="alert-icon">⚠</span>
        <span>Charter yoksa proje detayında empty state görünür. PMO_ADMIN ve PROJECT_MANAGER charter create/update yapabilir.</span>
      </div>

      {editing ? (
        <Card title={charter?.exists ? "Charter Güncelle" : "Charter Oluştur"} meta={charter?.exists ? `Versiyon ${charter.version}` : "Yeni charter"}>
          <div className="form-grid">
            <label className="form-field form-field-full">
              <span>Amaç</span>
              <textarea value={form.purpose} onChange={(event) => setForm({ ...form, purpose: event.target.value })} />
            </label>
            <label className="form-field form-field-full">
              <span>Hedefler</span>
              <textarea value={form.objectives} onChange={(event) => setForm({ ...form, objectives: event.target.value })} />
            </label>
            <label className="form-field form-field-full">
              <span>Scope</span>
              <textarea value={form.scope} onChange={(event) => setForm({ ...form, scope: event.target.value })} />
            </label>
            <label className="form-field form-field-full">
              <span>Out Of Scope</span>
              <textarea value={form.outOfScope} onChange={(event) => setForm({ ...form, outOfScope: event.target.value })} />
            </label>
            <label className="form-field form-field-full">
              <span>Başarı Kriterleri</span>
              <textarea value={form.successCriteria} onChange={(event) => setForm({ ...form, successCriteria: event.target.value })} />
            </label>
            <label className="form-field form-field-full">
              <span>Riskler ve Varsayımlar</span>
              <textarea value={form.risksAndAssumptions} onChange={(event) => setForm({ ...form, risksAndAssumptions: event.target.value })} />
            </label>
            <label className="form-field form-field-full">
              <span>Bağımlılıklar</span>
              <textarea value={form.dependencies} onChange={(event) => setForm({ ...form, dependencies: event.target.value })} />
            </label>
            <label className="form-field form-field-full">
              <span>Paydaşlar</span>
              <textarea value={form.stakeholders} onChange={(event) => setForm({ ...form, stakeholders: event.target.value })} />
            </label>
            <label className="form-field form-field-full">
              <span>Takvim Özeti</span>
              <textarea value={form.timelineSummary} onChange={(event) => setForm({ ...form, timelineSummary: event.target.value })} />
            </label>
            <label className="form-field form-field-full">
              <span>Bütçe Özeti</span>
              <textarea value={form.budgetSummary} onChange={(event) => setForm({ ...form, budgetSummary: event.target.value })} />
            </label>
            <label className="form-field form-field-full">
              <span>Onay Notları</span>
              <textarea value={form.approvalNotes} onChange={(event) => setForm({ ...form, approvalNotes: event.target.value })} />
            </label>
          </div>
          {error ? <div className="alert alert-warning" style={{ marginTop: 16 }}><span className="alert-icon">!</span><span>{error}</span></div> : null}
          <div className="form-actions">
            <button className="btn btn-secondary" type="button" onClick={() => setEditing(false)}>
              İptal
            </button>
            <button className="btn btn-primary" type="button" disabled={saving} onClick={() => void handleSave()}>
              {saving ? "Kaydediliyor..." : charter?.exists ? "Charter Güncelle" : "Charter Oluştur"}
            </button>
          </div>
        </Card>
      ) : charter?.exists ? (
        <>
          <Card title="Charter Özeti" meta={`Versiyon ${charter.version} · Son gözden geçirme ${charter.lastReviewedAtText ?? "-"}`}>
            <div className="detail-list">
              <div className="detail-row">
                <span>Proje</span>
                <strong>{projectDetail.name}</strong>
              </div>
              <div className="detail-row">
                <span>Kod</span>
                <strong>{projectDetail.code}</strong>
              </div>
              <div className="detail-row">
                <span>Durum</span>
                <strong>{projectDetail.status}</strong>
              </div>
            </div>
          </Card>
          <div className="grid-2">
            {charterSections.map((section) => (
              <Card key={section.title} title={section.title}>
                <div className="project-rich-text">{section.value}</div>
              </Card>
            ))}
          </div>
        </>
      ) : (
        <Card title="Charter Durumu" meta="Henüz oluşturulmadı">
          <EmptyState title="Bu proje için charter henüz oluşturulmadı" subtitle="İlk charter kaydını bu ekrandan oluşturabilirsiniz." />
          {charter?.canEdit ? (
            <div className="form-actions">
              <button className="btn btn-primary" type="button" onClick={() => setEditing(true)}>
                Charter Oluştur
              </button>
            </div>
          ) : null}
        </Card>
      )}

      <Toast open={toast.open} message={toast.message} tone={toast.tone} />
    </div>
  );
}
