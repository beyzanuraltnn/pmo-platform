import { useCallback, useEffect, useMemo, useState } from "react";
import { AxiosError } from "axios";
import { useNavigate, useParams } from "react-router-dom";
import { projectService } from "../../api/services/projectService";
import type { CreateOrUpdateProjectRequest, ProjectDetail } from "../../api/types";
import { useAuth } from "../../auth/AuthContext";
import { EmptyState } from "../../components/feedback/EmptyState";
import { ErrorState } from "../../components/feedback/ErrorState";
import { LoadingState } from "../../components/feedback/LoadingState";
import { Badge } from "../../components/ui/Badge";
import { Card } from "../../components/ui/Card";
import { PageHeader } from "../../components/ui/PageHeader";
import { Toast } from "../../components/ui/Toast";

const projectTypes = ["Regulation", "Integration", "Product", "Infrastructure"] as const;
const projectStatuses = ["Planned", "Active", "Completed", "Cancelled"] as const;
const projectPriorities = ["Low", "Medium", "High", "Critical"] as const;
const ragOptions = ["Green", "Yellow", "Red"] as const;
const stageOptions = ["Initiation", "Analysis", "Development", "Test", "GoLive", "Closure"] as const;

const emptyForm: CreateOrUpdateProjectRequest = {
  name: "",
  code: "",
  type: "Product",
  status: "Planned",
  description: "",
  businessOwner: "",
  projectManagerId: "",
  sponsor: "",
  priority: "Medium",
  ragStatus: "Green",
  stage: "Initiation",
  plannedStartDate: "",
  plannedEndDate: "",
  expectedGoLiveDate: "",
  actualGoLiveDate: "",
  budget: null,
  department: "",
  notes: ""
};

function getErrorMessage(error: unknown, fallback: string) {
  if (error instanceof AxiosError) {
    return (error.response?.data as { message?: string } | undefined)?.message ?? fallback;
  }

  return fallback;
}

function getRagTone(rag?: string) {
  if (rag?.toLowerCase() === "green") return "green";
  if (rag?.toLowerCase() === "yellow") return "yellow";
  return "red";
}

function toDateInput(value?: string | null) {
  return value ? value.slice(0, 10) : "";
}

export function ProjectDetailPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { user } = useAuth();
  const isCreateMode = id === "new";
  const [detail, setDetail] = useState<ProjectDetail | null>(null);
  const [summary, setSummary] = useState<{ charterExists: boolean; latestGateStatus: string; notificationCount: number } | null>(null);
  const [form, setForm] = useState<CreateOrUpdateProjectRequest>(emptyForm);
  const [loading, setLoading] = useState(!isCreateMode);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState(isCreateMode);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<{ open: boolean; message: string; tone: "default" | "success" | "warning" }>({
    open: false,
    message: "",
    tone: "default"
  });

  const canCreate = user?.role === "PMO_ADMIN" || user?.role === "PROJECT_MANAGER";

  useEffect(() => {
    if (!toast.open) return undefined;
    const timer = window.setTimeout(() => setToast((current) => ({ ...current, open: false })), 2600);
    return () => window.clearTimeout(timer);
  }, [toast.open]);

  const loadProject = useCallback(async () => {
    if (!id || isCreateMode) {
      setForm((current) => ({
        ...current,
        projectManagerId: user?.id ?? "",
        businessOwner: current.businessOwner || user?.fullName || "",
        sponsor: current.sponsor || user?.fullName || ""
      }));
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const [projectDetail, projectSummary] = await Promise.all([projectService.getProjectDetail(id), projectService.getProjectSummary(id)]);
      setDetail(projectDetail);
      setSummary(projectSummary);
      setForm({
        name: projectDetail.name,
        code: projectDetail.code,
        type: projectDetail.type === "Regülasyon" ? "Regulation" : projectDetail.type === "Entegrasyon" ? "Integration" : projectDetail.type === "Ürün" ? "Product" : "Infrastructure",
        status: projectDetail.status,
        description: projectDetail.description,
        businessOwner: projectDetail.businessOwner,
        projectManagerId: projectDetail.projectManagerId ?? user?.id ?? "",
        sponsor: projectDetail.sponsor,
        priority:
          projectDetail.priority === "Kritik" ? "Critical" : projectDetail.priority === "Yüksek" ? "High" : projectDetail.priority === "Düşük" ? "Low" : "Medium",
        ragStatus: projectDetail.ragStatus ?? "Green",
        stage:
          projectDetail.stage === "Başlatma"
            ? "Initiation"
            : projectDetail.stage === "Analiz"
              ? "Analysis"
              : projectDetail.stage === "Test"
                ? "Test"
                : projectDetail.stage === "Go-Live"
                  ? "GoLive"
                  : projectDetail.stage === "Kapanış"
                    ? "Closure"
                    : "Development",
        plannedStartDate: toDateInput(projectDetail.plannedStartDate),
        plannedEndDate: toDateInput(projectDetail.plannedEndDate),
        expectedGoLiveDate: toDateInput(projectDetail.expectedGoLiveDate),
        actualGoLiveDate: toDateInput(projectDetail.actualGoLiveDate),
        budget: projectDetail.budgetText && projectDetail.budgetText !== "-" ? Number(projectDetail.budgetText.replace(/[^\d,-]/g, "").replace(/\./g, "").replace(",", ".")) : null,
        department: projectDetail.department,
        notes: projectDetail.notes
      });
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Proje detayı yüklenemedi."));
    } finally {
      setLoading(false);
    }
  }, [id, isCreateMode, user?.fullName, user?.id]);

  useEffect(() => {
    void loadProject();
  }, [loadProject]);

  const projectMetaRows = useMemo(() => {
    if (!detail) return [];

    return [
      { label: "Proje Kodu", value: detail.code },
      { label: "Tür", value: detail.type },
      { label: "Durum", value: detail.status },
      { label: "Öncelik", value: detail.priority ?? "-" },
      { label: "Business Owner", value: detail.businessOwner },
      { label: "Project Manager", value: detail.projectManager },
      { label: "Sponsor", value: detail.sponsor },
      { label: "Departman", value: detail.department }
    ];
  }, [detail]);

  const dateRows = useMemo(() => {
    if (!detail) return [];

    return [
      { label: "Planlanan Başlangıç", value: detail.plannedStartDateText ?? "-" },
      { label: "Planlanan Bitiş", value: detail.plannedEndDateText ?? "-" },
      { label: "Beklenen Go-Live", value: detail.expectedGoLiveDateText ?? "-" },
      { label: "Gerçek Go-Live", value: detail.actualGoLiveDateText ?? "-" },
      { label: "Bütçe", value: detail.budgetText ?? "-" },
      { label: "Stage Gate", value: detail.stageGateStatus ?? "-" }
    ];
  }, [detail]);

  const handleSubmit = async () => {
    if (!canCreate && isCreateMode) {
      setToast({ open: true, message: "Bu işlem için yetkiniz yok.", tone: "warning" });
      return;
    }

    if (!form.projectManagerId) {
      setForm((current) => ({ ...current, projectManagerId: user?.id ?? "" }));
    }

    setSaving(true);
    setError(null);

    try {
      const payload = {
        ...form,
        projectManagerId: form.projectManagerId || user?.id || "",
        plannedStartDate: form.plannedStartDate || null,
        plannedEndDate: form.plannedEndDate || null,
        expectedGoLiveDate: form.expectedGoLiveDate || null,
        actualGoLiveDate: form.actualGoLiveDate || null
      };

      const response = isCreateMode ? await projectService.createProject(payload) : await projectService.updateProject(id!, payload);
      setDetail(response);
      setEditing(false);
      setToast({ open: true, message: isCreateMode ? "Proje oluşturuldu." : "Proje güncellendi.", tone: "success" });

      if (isCreateMode && response.id) {
        navigate(`/projects/${response.id}`, { replace: true });
      } else if (id) {
        const projectSummary = await projectService.getProjectSummary(id);
        setSummary(projectSummary);
      }
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Proje kaydedilemedi."));
      setToast({ open: true, message: "Proje kaydı başarısız.", tone: "warning" });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <LoadingState message="Proje detayı yükleniyor..." />;
  }

  if (error && !editing && !isCreateMode) {
    return <ErrorState message={error} onRetry={() => void loadProject()} />;
  }

  if (!isCreateMode && !detail) {
    return <EmptyState title="Proje bulunamadı" subtitle="Liste ekranından tekrar seçim yapın." />;
  }

  if (isCreateMode && !canCreate) {
    return <EmptyState title="Yeni proje oluşturma yetkiniz yok" subtitle="Bu işlem yalnızca PMO_ADMIN ve PROJECT_MANAGER için açıktır." />;
  }

  return (
    <div className="placeholder-stack">
      <PageHeader
        title={isCreateMode ? "Yeni Proje" : detail?.name ?? "Proje Detayı"}
        subtitle={isCreateMode ? "Portföye yeni proje kaydı ekleyin." : `${detail?.code ?? ""} · Proje ve charter yaşam döngüsünün temel kaydı`}
        actions={
          <>
            {!isCreateMode && detail?.id ? (
              <button className="btn btn-secondary" type="button" onClick={() => navigate(`/projects/${detail.id}/raid`)}>
                RAID
              </button>
            ) : null}
            {!isCreateMode && detail?.id ? (
              <button className="btn btn-secondary" type="button" onClick={() => navigate(`/projects/${detail.id}/charter`)}>
                Charter
              </button>
            ) : null}
            {!isCreateMode && detail?.canEdit ? (
              <button className="btn btn-primary" type="button" onClick={() => setEditing((current) => !current)}>
                {editing ? "Formu Kapat" : "Düzenle"}
              </button>
            ) : null}
          </>
        }
      />

      {editing ? (
        <Card title={isCreateMode ? "Proje Oluştur" : "Proje Güncelle"} meta="Gerçek API verisi ile çalışır">
          <div className="form-grid">
            <label className="form-field">
              <span>Proje Adı</span>
              <input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} />
            </label>
            <label className="form-field">
              <span>Proje Kodu</span>
              <input value={form.code} onChange={(event) => setForm({ ...form, code: event.target.value.toUpperCase() })} />
            </label>
            <label className="form-field">
              <span>Tür</span>
              <select value={form.type} onChange={(event) => setForm({ ...form, type: event.target.value })}>
                {projectTypes.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>
            <label className="form-field">
              <span>Durum</span>
              <select value={form.status} onChange={(event) => setForm({ ...form, status: event.target.value })}>
                {projectStatuses.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>
            <label className="form-field">
              <span>Business Owner</span>
              <input value={form.businessOwner} onChange={(event) => setForm({ ...form, businessOwner: event.target.value })} />
            </label>
            <label className="form-field">
              <span>Project Manager</span>
              <input value={detail?.projectManager ?? user?.fullName ?? ""} readOnly />
            </label>
            <label className="form-field">
              <span>Sponsor</span>
              <input value={form.sponsor} onChange={(event) => setForm({ ...form, sponsor: event.target.value })} />
            </label>
            <label className="form-field">
              <span>Departman</span>
              <input value={form.department} onChange={(event) => setForm({ ...form, department: event.target.value })} />
            </label>
            <label className="form-field">
              <span>Öncelik</span>
              <select value={form.priority} onChange={(event) => setForm({ ...form, priority: event.target.value })}>
                {projectPriorities.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>
            <label className="form-field">
              <span>RAG</span>
              <select value={form.ragStatus} onChange={(event) => setForm({ ...form, ragStatus: event.target.value })}>
                {ragOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>
            <label className="form-field">
              <span>Aşama</span>
              <select value={form.stage} onChange={(event) => setForm({ ...form, stage: event.target.value })}>
                {stageOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>
            <label className="form-field">
              <span>Bütçe</span>
              <input
                type="number"
                value={form.budget ?? ""}
                onChange={(event) => setForm({ ...form, budget: event.target.value ? Number(event.target.value) : null })}
              />
            </label>
            <label className="form-field">
              <span>Planlanan Başlangıç</span>
              <input type="date" value={form.plannedStartDate ?? ""} onChange={(event) => setForm({ ...form, plannedStartDate: event.target.value })} />
            </label>
            <label className="form-field">
              <span>Planlanan Bitiş</span>
              <input type="date" value={form.plannedEndDate ?? ""} onChange={(event) => setForm({ ...form, plannedEndDate: event.target.value })} />
            </label>
            <label className="form-field">
              <span>Beklenen Go-Live</span>
              <input type="date" value={form.expectedGoLiveDate ?? ""} onChange={(event) => setForm({ ...form, expectedGoLiveDate: event.target.value })} />
            </label>
            <label className="form-field">
              <span>Gerçek Go-Live</span>
              <input type="date" value={form.actualGoLiveDate ?? ""} onChange={(event) => setForm({ ...form, actualGoLiveDate: event.target.value })} />
            </label>
            <label className="form-field form-field-full">
              <span>Açıklama</span>
              <textarea value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} />
            </label>
            <label className="form-field form-field-full">
              <span>Notlar</span>
              <textarea value={form.notes} onChange={(event) => setForm({ ...form, notes: event.target.value })} />
            </label>
          </div>
          {error ? <div className="alert alert-warning" style={{ marginTop: 16 }}><span className="alert-icon">!</span><span>{error}</span></div> : null}
          <div className="form-actions">
            {!isCreateMode ? (
              <button className="btn btn-secondary" type="button" onClick={() => setEditing(false)}>
                İptal
              </button>
            ) : null}
            <button className="btn btn-primary" type="button" disabled={saving} onClick={() => void handleSubmit()}>
              {saving ? "Kaydediliyor..." : isCreateMode ? "Projeyi Oluştur" : "Değişiklikleri Kaydet"}
            </button>
          </div>
        </Card>
      ) : detail ? (
        <>
          <div className="grid-2">
            <Card title="Temel Bilgiler" meta={summary?.charterExists ? "Charter mevcut" : "Charter henüz yok"}>
              <div className="detail-list">
                {projectMetaRows.map((item) => (
                  <div className="detail-row" key={item.label}>
                    <span>{item.label}</span>
                    <strong>{item.value}</strong>
                  </div>
                ))}
              </div>
            </Card>
            <Card title="Takvim ve Özet" meta={`${summary?.notificationCount ?? 0} bildirim`}>
              <div className="detail-list">
                {dateRows.map((item) => (
                  <div className="detail-row" key={item.label}>
                    <span>{item.label}</span>
                    <strong>{item.value}</strong>
                  </div>
                ))}
                <div className="detail-row">
                  <span>RAG</span>
                  <Badge tone={getRagTone(detail.ragStatus)}>{detail.ragStatus ?? "-"}</Badge>
                </div>
              </div>
            </Card>
          </div>
          <Card title="Proje Açıklaması" meta={detail.charterExists ? "Charter ekranına geçebilirsiniz" : "Charter oluşturulmadı"}>
            <div className="project-rich-text">{detail.description}</div>
            <div className="project-rich-sub">{detail.notes}</div>
          </Card>
        </>
      ) : null}

      <Toast open={toast.open} message={toast.message} tone={toast.tone} />
    </div>
  );
}
