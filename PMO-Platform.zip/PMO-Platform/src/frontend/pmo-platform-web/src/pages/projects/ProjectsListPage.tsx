import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { projectService } from "../../api/services/projectService";
import type { ProjectListItem } from "../../api/types";
import { useAuth } from "../../auth/AuthContext";
import { EmptyState } from "../../components/feedback/EmptyState";
import { ErrorState } from "../../components/feedback/ErrorState";
import { LoadingState } from "../../components/feedback/LoadingState";
import { Badge } from "../../components/ui/Badge";
import { Card } from "../../components/ui/Card";
import { PageHeader } from "../../components/ui/PageHeader";
import { Table } from "../../components/ui/Table";

type ProjectsListVariant = "active" | "planned" | "completed";

type ProjectsListPageProps = {
  variant: ProjectsListVariant;
};

const pageConfig: Record<
  ProjectsListVariant,
  {
    title: string;
    subtitle: string;
    status: string;
    cardTitle: string;
    cardMeta: string;
  }
> = {
  active: {
    title: "Aktif Projeler",
    subtitle: "Aktif olarak yürütülen projelerin merkezi görünümü",
    status: "Active",
    cardTitle: "Aktif Proje Listesi",
    cardMeta: "Canlı API verisi ile portföy görünümü"
  },
  planned: {
    title: "Planlanan Projeler",
    subtitle: "Henüz başlatılmamış, planlama aşamasındaki projeler",
    status: "Planned",
    cardTitle: "Planlanan Proje Listesi",
    cardMeta: "Canlı API verisi ile planlama havuzu"
  },
  completed: {
    title: "Tamamlanan Projeler",
    subtitle: "Resmi olarak kapatılmış proje arşivi",
    status: "Completed",
    cardTitle: "Tamamlanan Proje Arşivi",
    cardMeta: "Canlı API verisi ile kapanış arşivi"
  }
};

function getTypeTone(type: string) {
  if (type.toLowerCase().includes("entegrasyon")) return "blue";
  if (type.toLowerCase().includes("ürün") || type.toLowerCase().includes("urun")) return "purple";
  if (type.toLowerCase().includes("reg")) return "red";
  return "gray";
}

function getRagTone(rag?: string) {
  const normalized = rag?.toLowerCase();
  if (normalized === "green") return "green";
  if (normalized === "yellow") return "yellow";
  return "red";
}

function getRiskTone(risk?: string) {
  const normalized = risk?.toLowerCase();
  if (normalized?.includes("düşük") || normalized?.includes("dusuk") || normalized?.includes("low")) return "green";
  if (normalized?.includes("orta") || normalized?.includes("medium")) return "yellow";
  return "red";
}

export function ProjectsListPage({ variant }: ProjectsListPageProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const config = pageConfig[variant];
  const [projects, setProjects] = useState<ProjectListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProjects = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const data = await projectService.getProjects(config.status);
      setProjects(data);
    } catch {
      setError("Proje listesi yüklenemedi.");
      setProjects([]);
    } finally {
      setLoading(false);
    }
  }, [config.status]);

  useEffect(() => {
    void fetchProjects();
  }, [fetchProjects]);

  const rows = useMemo(() => {
    if (variant === "active") {
      return projects.map((project) => [
        <button key={`${project.name}-name`} className="table-link" type="button" onClick={() => navigate(`/projects/${project.id}`)}>
          <strong>{project.name}</strong>
          <span className="stage-gate-muted">{project.code}</span>
        </button>,
        <Badge key={`${project.name}-type`} tone={getTypeTone(project.type)}>
          {project.type}
        </Badge>,
        project.projectManager,
        <Badge key={`${project.name}-stage`} tone={project.stage?.toLowerCase() === "analiz" ? "gray" : project.stage?.toLowerCase() === "development" ? "yellow" : "red"}>
          {project.stage ?? "-"}
        </Badge>,
        <span className="rag" key={`${project.name}-rag`}>
          <span className={`rag-dot ${getRagTone(project.ragStatus)}`} />
          {project.ragStatus ?? "-"}
        </span>,
        <span key={`${project.name}-date`} style={{ fontFamily: "var(--mono)", fontSize: 12 }}>
          {project.goLiveDateText ?? "-"}
        </span>,
        <Badge key={`${project.name}-risk`} tone={getRiskTone(project.riskLevel)}>
          {project.riskLevel ?? "-"}
        </Badge>
      ]);
    }

    if (variant === "planned") {
      return projects.map((project) => [
        <button key={`${project.name}-name`} className="table-link" type="button" onClick={() => navigate(`/projects/${project.id}`)}>
          <strong>{project.name}</strong>
          <span className="stage-gate-muted">{project.code}</span>
        </button>,
        <Badge key={`${project.name}-type`} tone={getTypeTone(project.type)}>
          {project.type}
        </Badge>,
        <Badge key={`${project.name}-priority`} tone={getRiskTone(project.priority)}>
          {project.priority ?? "-"}
        </Badge>,
        <span key={`${project.name}-start`} style={{ fontFamily: "var(--mono)", fontSize: 12 }}>
          {project.plannedStartText ?? "-"}
        </span>,
        <span key={`${project.name}-golive`} style={{ fontFamily: "var(--mono)", fontSize: 12 }}>
          {project.expectedGoLiveText ?? "-"}
        </span>,
        <span key={`${project.name}-note`} style={{ fontSize: 12, color: "var(--ink3)" }}>
          {project.note ?? "-"}
        </span>
      ]);
    }

    return projects.map((project) => [
      <button key={`${project.name}-name`} className="table-link" type="button" onClick={() => navigate(`/projects/${project.id}`)}>
        <strong>{project.name}</strong>
        <span className="stage-gate-muted">{project.code}</span>
      </button>,
      <Badge key={`${project.name}-type`} tone={getTypeTone(project.type)}>
        {project.type}
      </Badge>,
      <span key={`${project.name}-golive`} style={{ fontFamily: "var(--mono)", fontSize: 12 }}>
        {project.goLiveDateText ?? "-"}
      </span>,
      project.projectManager,
      <span key={`${project.name}-sv`} style={{ fontFamily: "var(--mono)", fontSize: 12 }}>
        {project.scheduleVarianceText ?? "-"}
      </span>,
      <span key={`${project.name}-uat`} style={{ fontFamily: "var(--mono)", fontSize: 12 }}>
        {project.uatRateText ?? "-"}
      </span>
    ]);
  }, [navigate, projects, variant]);

  const columns =
    variant === "active"
      ? ["Proje", "Tür", "PM", "Aşama", "Durum", "Go-Live", "Risk"]
      : variant === "planned"
        ? ["Proje", "Tür", "Öncelik", "Planlanan Başlangıç", "Beklenen Go-Live", "Not"]
        : ["Proje", "Tür", "Go-Live Tarihi", "PM", "SV (gün)", "UAT %"];

  return (
    <>
      <PageHeader
        title={config.title}
        subtitle={config.subtitle}
        actions={
          variant === "active" ? (
            <>
              <select className="inline-select" defaultValue={config.status}>
                <option value="Active">Aktif</option>
              </select>
              {user?.role === "PMO_ADMIN" || user?.role === "PROJECT_MANAGER" ? (
                <button className="btn btn-primary" type="button" onClick={() => navigate("/projects/new")}>
                  + Proje Ekle
                </button>
              ) : null}
            </>
          ) : variant === "planned" ? (
            user?.role === "PMO_ADMIN" || user?.role === "PROJECT_MANAGER" ? (
              <button className="btn btn-primary" type="button" onClick={() => navigate("/projects/new")}>
                + Planlanan Proje Ekle
              </button>
            ) : undefined
          ) : undefined
        }
      />

      {variant === "planned" ? (
        <div className="alert alert-info">
          <span className="alert-icon">ℹ</span>
          <span>
            Bu sayfadaki projeler aktif geliştirme sürecine girmemiştir. Charter onayı alınmadan proje aktifleşemez.
            <strong> (IK-01)</strong>
          </span>
        </div>
      ) : null}

      <Card title={config.cardTitle} meta={config.cardMeta} bodyClassName="card-body-0">
        {loading ? (
          <LoadingState message="Proje listesi yükleniyor..." />
        ) : error ? (
          <ErrorState message={error} onRetry={() => void fetchProjects()} />
        ) : rows.length === 0 ? (
          <EmptyState title="Bu filtre için proje bulunamadı" subtitle="API boş liste döndü." />
        ) : (
          <Table columns={columns} rows={rows} />
        )}
      </Card>
    </>
  );
}
