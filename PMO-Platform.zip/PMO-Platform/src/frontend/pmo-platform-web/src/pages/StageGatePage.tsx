import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AxiosError } from "axios";
import { gateService } from "../api/services/gateService";
import { projectService } from "../api/services/projectService";
import type { GateDetail, GateListItem, ProjectListItem } from "../api/types";
import { useAuth } from "../auth/AuthContext";
import { EmptyState } from "../components/feedback/EmptyState";
import { ErrorState } from "../components/feedback/ErrorState";
import { LoadingState } from "../components/feedback/LoadingState";
import { Badge } from "../components/ui/Badge";
import { Card } from "../components/ui/Card";
import { PageHeader } from "../components/ui/PageHeader";
import { Toast } from "../components/ui/Toast";

const evidenceCategories = ["TestKaniti", "UatKaniti", "Regresyon", "Guvenlik", "Operasyon", "Diger"] as const;

function getGateTone(status: string) {
  switch (status) {
    case "Approved":
      return "green";
    case "ReadyForSubmit":
      return "blue";
    case "WaitingApproval":
      return "yellow";
    case "Rejected":
      return "red";
    default:
      return "gray";
  }
}

function getGateLabel(status: string) {
  switch (status) {
    case "Draft":
      return "Taslak";
    case "MissingEvidence":
      return "Eksik Kanıt";
    case "ReadyForSubmit":
      return "Gönderime Hazır";
    case "WaitingApproval":
      return "Onay Bekliyor";
    case "Approved":
      return "Onaylandı";
    case "Rejected":
      return "Reddedildi";
    default:
      return status;
  }
}

function getApprovalLabel(status: string) {
  switch (status) {
    case "Pending":
      return "Beklemede";
    case "Approved":
      return "Onaylandı";
    case "Rejected":
      return "Reddedildi";
    default:
      return status;
  }
}

function getErrorMessage(error: unknown, fallback: string) {
  if (error instanceof AxiosError) {
    return (error.response?.data as { message?: string } | undefined)?.message ?? fallback;
  }

  return fallback;
}

export function StageGatePage() {
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [projects, setProjects] = useState<ProjectListItem[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string>("");
  const [gates, setGates] = useState<GateListItem[]>([]);
  const [selectedGateId, setSelectedGateId] = useState<string>("");
  const [gateDetail, setGateDetail] = useState<GateDetail | null>(null);
  const [pageLoading, setPageLoading] = useState(true);
  const [listLoading, setListLoading] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState("");
  const [toastTone, setToastTone] = useState<"default" | "success" | "warning">("default");
  const [toastOpen, setToastOpen] = useState(false);
  const [actionNote, setActionNote] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<(typeof evidenceCategories)[number]>("TestKaniti");
  const [isRequiredEvidence, setIsRequiredEvidence] = useState(true);
  const [busyAction, setBusyAction] = useState<"upload" | "submit" | "approve" | "reject" | "delete" | null>(null);

  const canManageGate = user?.role === "PROJECT_MANAGER" || user?.role === "PMO_ADMIN";

  const showToast = useCallback((message: string, tone: "default" | "success" | "warning" = "default") => {
    setToastMessage(message);
    setToastTone(tone);
    setToastOpen(true);
  }, []);

  useEffect(() => {
    if (!toastOpen) {
      return undefined;
    }

    const timer = window.setTimeout(() => setToastOpen(false), 2800);
    return () => window.clearTimeout(timer);
  }, [toastOpen]);

  const fetchProjects = useCallback(async () => {
    setPageLoading(true);
    setError(null);

    try {
      const data = await projectService.getProjects();
      setProjects(data);
      setSelectedProjectId((current) => current || data[0]?.id || "");
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Projeler yüklenemedi."));
      setProjects([]);
    } finally {
      setPageLoading(false);
    }
  }, []);

  const fetchGates = useCallback(async (projectId: string, preferredGateId?: string) => {
    if (!projectId) {
      setGates([]);
      setSelectedGateId("");
      setGateDetail(null);
      return;
    }

    setListLoading(true);
    setError(null);

    try {
      const data = await gateService.getProjectGates(projectId);
      setGates(data);
      const nextGateId = preferredGateId && data.some((gate) => gate.id === preferredGateId) ? preferredGateId : data[0]?.id ?? "";
      setSelectedGateId(nextGateId);
    } catch (requestError) {
      setError(getErrorMessage(requestError, "Gate listesi yüklenemedi."));
      setGates([]);
      setSelectedGateId("");
      setGateDetail(null);
    } finally {
      setListLoading(false);
    }
  }, []);

  const fetchGateDetail = useCallback(async (gateId: string) => {
    if (!gateId) {
      setGateDetail(null);
      return;
    }

    setDetailLoading(true);
    setActionError(null);

    try {
      const data = await gateService.getGateDetail(gateId);
      setGateDetail(data);
    } catch (requestError) {
      setActionError(getErrorMessage(requestError, "Gate detayı yüklenemedi."));
      setGateDetail(null);
    } finally {
      setDetailLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchProjects();
  }, [fetchProjects]);

  useEffect(() => {
    if (!selectedProjectId) {
      return;
    }

    void fetchGates(selectedProjectId, selectedGateId);
  }, [fetchGates, selectedProjectId]);

  useEffect(() => {
    if (!selectedGateId) {
      return;
    }

    void fetchGateDetail(selectedGateId);
  }, [fetchGateDetail, selectedGateId]);

  const refreshCurrentProject = useCallback(
    async (preferredGateId?: string) => {
      if (!selectedProjectId) {
        return;
      }

      await fetchGates(selectedProjectId, preferredGateId ?? selectedGateId);
      const nextGateId = preferredGateId ?? selectedGateId;
      if (nextGateId) {
        await fetchGateDetail(nextGateId);
      }
    },
    [fetchGateDetail, fetchGates, selectedGateId, selectedProjectId]
  );

  const handleUpload = useCallback(async () => {
    if (!selectedGateId || !selectedFile) {
      setActionError("Önce bir dosya seçin.");
      return;
    }

    setBusyAction("upload");
    setActionError(null);

    try {
      await gateService.uploadEvidence(selectedGateId, {
        file: selectedFile,
        category: selectedCategory,
        isRequired: isRequiredEvidence
      });

      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }

      await refreshCurrentProject(selectedGateId);
      showToast("Kanıt dosyası yüklendi.", "success");
    } catch (requestError) {
      setActionError(getErrorMessage(requestError, "Kanıt yüklenemedi."));
      showToast("Kanıt yükleme başarısız.", "warning");
    } finally {
      setBusyAction(null);
    }
  }, [isRequiredEvidence, refreshCurrentProject, selectedCategory, selectedFile, selectedGateId, showToast]);

  const handleSubmit = useCallback(async () => {
    if (!selectedGateId) {
      return;
    }

    setBusyAction("submit");
    setActionError(null);

    try {
      const data = await gateService.submitGate(selectedGateId);
      setGateDetail(data);
      await fetchGates(selectedProjectId, selectedGateId);
      showToast("Gate onaya gönderildi.", "success");
    } catch (requestError) {
      setActionError(getErrorMessage(requestError, "Gate onaya gönderilemedi."));
      showToast("Submit işlemi başarısız.", "warning");
    } finally {
      setBusyAction(null);
    }
  }, [fetchGates, selectedGateId, selectedProjectId, showToast]);

  const handleApprove = useCallback(async () => {
    if (!selectedGateId) {
      return;
    }

    setBusyAction("approve");
    setActionError(null);

    try {
      const data = await gateService.approveGate(selectedGateId, actionNote.trim() || undefined);
      setGateDetail(data);
      setActionNote("");
      await fetchGates(selectedProjectId, selectedGateId);
      showToast("Gate onayı kaydedildi.", "success");
    } catch (requestError) {
      setActionError(getErrorMessage(requestError, "Approve işlemi tamamlanamadı."));
      showToast("Approve işlemi başarısız.", "warning");
    } finally {
      setBusyAction(null);
    }
  }, [actionNote, fetchGates, selectedGateId, selectedProjectId, showToast]);

  const handleReject = useCallback(async () => {
    if (!selectedGateId) {
      return;
    }

    if (!actionNote.trim()) {
      setActionError("Ret notu zorunludur.");
      return;
    }

    setBusyAction("reject");
    setActionError(null);

    try {
      const data = await gateService.rejectGate(selectedGateId, actionNote.trim());
      setGateDetail(data);
      setActionNote("");
      await fetchGates(selectedProjectId, selectedGateId);
      showToast("Gate reddedildi.", "success");
    } catch (requestError) {
      setActionError(getErrorMessage(requestError, "Reject işlemi tamamlanamadı."));
      showToast("Reject işlemi başarısız.", "warning");
    } finally {
      setBusyAction(null);
    }
  }, [actionNote, fetchGates, selectedGateId, selectedProjectId, showToast]);

  const handleDeleteEvidence = useCallback(
    async (evidenceId: string) => {
      if (!selectedGateId) {
        return;
      }

      setBusyAction("delete");
      setActionError(null);

      try {
        await gateService.deleteEvidence(selectedGateId, evidenceId);
        await refreshCurrentProject(selectedGateId);
        showToast("Kanıt dosyası silindi.", "success");
      } catch (requestError) {
        setActionError(getErrorMessage(requestError, "Kanıt silinemedi."));
        showToast("Silme işlemi başarısız.", "warning");
      } finally {
        setBusyAction(null);
      }
    },
    [refreshCurrentProject, selectedGateId, showToast]
  );

  const gateRows = useMemo(
    () =>
      gates.map((gate) => [
        <button
          key={`${gate.id}-select`}
          type="button"
          className={`stage-gate-link ${gate.id === selectedGateId ? "active" : ""}`.trim()}
          onClick={() => setSelectedGateId(gate.id)}
        >
          <strong>Gate {gate.gateNo}</strong>
          <span>{gate.name}</span>
        </button>,
        <Badge key={`${gate.id}-status`} tone={getGateTone(gate.status)}>
          {getGateLabel(gate.status)}
        </Badge>,
        <span key={`${gate.id}-evidence`} className="mono-text">
          {gate.uploadedEvidenceCount}/{gate.requiredEvidenceCount}
        </span>,
        <span key={`${gate.id}-pending`} className="mono-text">
          {gate.pendingApprovalCount}
        </span>,
        <span key={`${gate.id}-owner`} className="stage-gate-muted">
          {gate.owner}
        </span>,
        <span key={`${gate.id}-note`} className="stage-gate-muted">
          {gate.note}
        </span>
      ]),
    [gates, selectedGateId]
  );

  const evidenceRows = useMemo(
    () =>
      gateDetail?.evidences.map((evidence) => (
        <div className="stage-gate-list-item" key={evidence.id}>
          <div>
            <div className="stage-gate-item-title">{evidence.fileName}</div>
            <div className="stage-gate-item-sub">
              {evidence.uploadedBy} · {evidence.uploadedAtText}
            </div>
          </div>
          <div className="stage-gate-item-actions">
            <Badge tone={evidence.isRequired ? "blue" : "gray"}>{evidence.isRequired ? "Zorunlu" : "Opsiyonel"}</Badge>
            <Badge tone="gray">{evidence.category}</Badge>
            {canManageGate && (gateDetail.status === "Draft" || gateDetail.status === "Rejected" || gateDetail.status === "MissingEvidence" || gateDetail.status === "ReadyForSubmit") ? (
              <button className="btn btn-secondary btn-xs" type="button" onClick={() => void handleDeleteEvidence(evidence.id)}>
                Sil
              </button>
            ) : null}
          </div>
        </div>
      )) ?? [],
    [canManageGate, gateDetail, handleDeleteEvidence]
  );

  const approvalRows = useMemo(
    () =>
      gateDetail?.approvals.map((approval) => (
        <div className="stage-gate-list-item" key={approval.id}>
          <div>
            <div className="stage-gate-item-title">{approval.approverName}</div>
            <div className="stage-gate-item-sub">
              {approval.role} {approval.decisionDateText ? `· ${approval.decisionDateText}` : ""}
            </div>
            {approval.note ? <div className="stage-gate-item-note">{approval.note}</div> : null}
          </div>
          <Badge tone={approval.status === "Approved" ? "green" : approval.status === "Rejected" ? "red" : "yellow"}>
            {getApprovalLabel(approval.status)}
          </Badge>
        </div>
      )) ?? [],
    [gateDetail]
  );

  if (pageLoading) {
    return <LoadingState message="Stage gate ekranı yükleniyor..." />;
  }

  if (error) {
    return <ErrorState message={error} onRetry={() => void fetchProjects()} />;
  }

  return (
    <div className="placeholder-stack">
      <PageHeader
        title="Stage Gate Checklist"
        subtitle="Kanıt tabanlı onay sistemi. Kanıt tamamlanmadan submit edilemez, tüm onaylar bitmeden gate kapanmaz."
        actions={
          <>
            <select className="inline-select" value={selectedProjectId} onChange={(event) => setSelectedProjectId(event.target.value)}>
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </select>
            <button className="btn btn-secondary" type="button" onClick={() => void refreshCurrentProject()}>
              Yenile
            </button>
          </>
        }
      />

      <div className="alert alert-info">
        <span className="alert-icon">ℹ</span>
        <span>
          Gate submit için zorunlu kanıt sayısı tamamlanmalı. Reject notu zorunludur ve workflow bilgileri kullanıcı/tarih/not ile saklanır.
        </span>
      </div>

      <div className="stage-gate-grid">
        <Card title="Gate Listesi" meta="Canlı API verisi" bodyClassName="card-body-0">
          {listLoading ? (
            <LoadingState message="Gate listesi yükleniyor..." />
          ) : gateRows.length === 0 ? (
            <EmptyState title="Bu proje için gate bulunamadı" subtitle="Seed verisini ve proje seçimini kontrol edin." />
          ) : (
            <table className="tbl">
              <thead>
                <tr>
                  <th>Gate</th>
                  <th>Durum</th>
                  <th>Kanıt</th>
                  <th>Bekleyen</th>
                  <th>Sahip</th>
                  <th>Not</th>
                </tr>
              </thead>
              <tbody>
                {gateRows.map((row, rowIndex) => (
                  <tr key={rowIndex}>{row.map((cell, cellIndex) => <td key={`${rowIndex}-${cellIndex}`}>{cell}</td>)}</tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>

        <Card title={gateDetail ? `Gate ${gateDetail.gateNo} Detayı` : "Gate Detayı"} meta={gateDetail?.name ?? "Seçilen gate bilgisi"} bodyClassName="card-body">
          {detailLoading ? (
            <LoadingState message="Gate detayı yükleniyor..." />
          ) : !gateDetail ? (
            <EmptyState title="Görüntülenecek gate yok" subtitle="Soldaki listeden bir gate seçin." />
          ) : (
            <div className="stage-gate-detail">
              <div className="stage-gate-summary">
                <div className="stage-gate-summary-item">
                  <span className="stage-gate-summary-label">Durum</span>
                  <Badge tone={getGateTone(gateDetail.status)}>{getGateLabel(gateDetail.status)}</Badge>
                </div>
                <div className="stage-gate-summary-item">
                  <span className="stage-gate-summary-label">Açılış</span>
                  <span className="mono-text">{gateDetail.openDateText}</span>
                </div>
                <div className="stage-gate-summary-item">
                  <span className="stage-gate-summary-label">Termin</span>
                  <span className="mono-text">{gateDetail.dueDateText}</span>
                </div>
                <div className="stage-gate-summary-item">
                  <span className="stage-gate-summary-label">Kapanış</span>
                  <span className="mono-text">{gateDetail.closedDateText ?? "-"}</span>
                </div>
                <div className="stage-gate-summary-item">
                  <span className="stage-gate-summary-label">Kanıt Oranı</span>
                  <span className="mono-text">
                    {gateDetail.uploadedEvidenceCount}/{gateDetail.requiredEvidenceCount}
                  </span>
                </div>
              </div>

              <div className="stage-gate-description">{gateDetail.description}</div>

              {actionError ? (
                <div className="alert alert-warning">
                  <span className="alert-icon">!</span>
                  <span>{actionError}</span>
                </div>
              ) : null}

              <div className="stage-gate-form">
                {canManageGate ? (
                  <>
                    <div className="stage-gate-form-row">
                      <select className="inline-select" value={selectedCategory} onChange={(event) => setSelectedCategory(event.target.value as (typeof evidenceCategories)[number])}>
                        {evidenceCategories.map((category) => (
                          <option key={category} value={category}>
                            {category}
                          </option>
                        ))}
                      </select>
                      <label className="stage-gate-check">
                        <input type="checkbox" checked={isRequiredEvidence} onChange={(event) => setIsRequiredEvidence(event.target.checked)} />
                        Zorunlu kanıt
                      </label>
                      <input ref={fileInputRef} type="file" hidden onChange={(event) => setSelectedFile(event.target.files?.[0] ?? null)} />
                      <button className="btn btn-secondary" type="button" onClick={() => fileInputRef.current?.click()}>
                        Dosya Seç
                      </button>
                      <button className="btn btn-primary" type="button" disabled={busyAction === "upload"} onClick={() => void handleUpload()}>
                        {busyAction === "upload" ? "Yükleniyor..." : "Kanıt Yükle"}
                      </button>
                    </div>
                    <div className="stage-gate-file-name">{selectedFile ? selectedFile.name : "Henüz dosya seçilmedi."}</div>
                  </>
                ) : (
                  <div className="stage-gate-file-name">Bu rolde kanıt yükleme yetkisi yok.</div>
                )}
                <textarea
                  className="stage-gate-note"
                  placeholder="Approve için opsiyonel, reject için zorunlu not girin..."
                  value={actionNote}
                  onChange={(event) => setActionNote(event.target.value)}
                />
                <div className="stage-gate-action-row">
                  {canManageGate ? (
                    <button className="btn btn-primary" type="button" disabled={!gateDetail.canSubmit || busyAction === "submit"} onClick={() => void handleSubmit()}>
                      {busyAction === "submit" ? "Gönderiliyor..." : "Onaya Gönder"}
                    </button>
                  ) : null}
                  {gateDetail.canApprove ? (
                    <button className="btn btn-secondary" type="button" disabled={busyAction === "approve"} onClick={() => void handleApprove()}>
                      {busyAction === "approve" ? "Kaydediliyor..." : "Approve"}
                    </button>
                  ) : null}
                  {gateDetail.canReject ? (
                    <button className="btn btn-danger" type="button" disabled={busyAction === "reject"} onClick={() => void handleReject()}>
                      {busyAction === "reject" ? "Kaydediliyor..." : "Reject"}
                    </button>
                  ) : null}
                </div>
              </div>

              <div className="stage-gate-section">
                <div className="card-title">Evidence Listesi</div>
                {evidenceRows.length === 0 ? <EmptyState title="Kanıt bulunamadı" subtitle="Bu gate için henüz dosya yüklenmedi." /> : evidenceRows}
              </div>

              <div className="stage-gate-section">
                <div className="card-title">Approval Listesi</div>
                {approvalRows.length === 0 ? <EmptyState title="Approval kaydı yok" subtitle="Submit sonrası approver kayıtları burada oluşur." /> : approvalRows}
              </div>
            </div>
          )}
        </Card>
      </div>

      <Toast message={toastMessage} tone={toastTone} open={toastOpen} />
    </div>
  );
}
