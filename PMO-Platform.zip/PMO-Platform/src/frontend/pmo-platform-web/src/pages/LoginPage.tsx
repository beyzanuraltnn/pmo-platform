import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

type LocationState = {
  from?: {
    pathname?: string;
  };
};

export function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();

  const [email, setEmail] = useState("admin@pmo.local");
  const [password, setPassword] = useState("demo");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const from = (location.state as LocationState | undefined)?.from?.pathname ?? "/dashboard";

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLoading(true);
    setError(null);

    try {
      await login({ email, password });
      navigate(from, { replace: true });
    } catch {
      setError("Giriş başarısız. Kullanıcı bilgilerinizi kontrol edin.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-brand">
          <div className="logo">
            <div className="logo-icon">P</div>
            PMO <span>Platform</span>
          </div>
          <div className="logo-sub auth-logo-sub">v2.0 · PAROLAPARA</div>
        </div>

        <div className="page-header auth-header">
          <div>
            <div className="page-title">Giriş Yap</div>
            <div className="page-sub">JWT tabanlı erişim · Türkçe arayüz · Kurumsal PMO Paneli</div>
          </div>
        </div>

        <form className="auth-form" onSubmit={handleSubmit}>
          <div className="field">
            <label>E-posta</label>
            <input value={email} onChange={(event) => setEmail(event.target.value)} type="email" placeholder="ornek@firma.com" />
          </div>

          <div className="field">
            <label>Şifre</label>
            <input value={password} onChange={(event) => setPassword(event.target.value)} type="password" placeholder="••••••••" />
          </div>

          {error ? <div className="alert alert-warning"><span className="alert-icon">⚠</span><span>{error}</span></div> : null}

          <button className="btn btn-primary auth-submit" type="submit" disabled={loading}>
            {loading ? "Giriş Yapılıyor..." : "Giriş Yap"}
          </button>
        </form>
      </div>
    </div>
  );
}
