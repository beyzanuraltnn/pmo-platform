import { useCallback, useEffect, useMemo, useState } from "react";
import { AxiosError } from "axios";
import { useNavigate, useParams } from "react-router-dom";
import { projectService } from "../api/services/projectService";
import { raidService } from "../api/services/raidService";
import type { CreateOrUpdateRaidItemRequest, ProjectListItem, RaidDetail, RaidListItem, RaidSummary } from "../api/types";
import { useAuth } from "../auth/AuthContext";
import { EmptyState } from "../components/feedback/EmptyState";
import { ErrorState } from "../components/feedback/ErrorState";
import { LoadingState } from "../components/feedback/LoadingState";
import { Badge } from "../components/ui/Badge";
import { Card } from "../components/ui/Card";
import { PageHeader } from "../components/ui/PageHeader";
import { Toast } from "../components/ui/Toast";

const raidTypes = ["Risk", "Issue", "Assumption", "Dependency"] as const;
const raidStatuses = ["Open", "InProgress", "Mitigated", "Closed", "Accepted", "Blocked"] as const;
const raidPriorities = ["Low", "Medium", "High", "Critical"] as const;
const raidImpacts = ["Low", "Medium", "High"] as const;

const emptyForm: CreateOrUpdateRaidItemRequest = {
  type: "Risk",
  title: "",
  description: "",
  status: "Open",
  priority: "High",
  impact: "High",
  owner: "",
  actionPlan: "",
  dueDate: "",
  note: ""
};

function getErrorMessage(error: unknown, fallback: string) {
  if (error instanceof AxiosError) {
    return (error.response?.data as { message?: string } | undefined)?.message ?? fallback;
  }

  return fallback;
}

function getTypeLabel(type: string) {
  switch (type) {
    case "Risk":
      return "Risk";
    case "Issue":
      return "Issue";
    case "Assumption":
      return "Assumption";
    case "Dependency":
      return "Dependency";
    default:
      return type;
  }
}

function getStatusLabel(status: string) {
  switch (status) {
    case "Open":
      return "Açık";
    case "InProgress":
      return "İşlemde";
    case "Mitigated":
      return "Mitige";
    case "Closed":
      return "Kapalı";
    case "Accepted":
      return "Kabul";
    case "Blocked":
      return "Bloke";
    default:
      return status;
  }
}

function getStatusTone(status?: string) {
  switch (status) {
    case "Closed":
    case "Mitigated":
      return "green";
    case "InProgress":
    case "Accepted":
      return "blue";
    case "Blocked":
      return "red";
    default:
      return "yellow";
  }
}

function getPriorityTone(priority?: string | null) {
  switch (priority) {
    case "Critical":
      return "red";
    case "High":
      return "yellow";
    case "Medium":
      return "blue";
    case "Low":
      return "gray";
    default:
      return "gray";
  }
}

function toDateInput(value?: string | null) {
  return value ? value.slice(0, 10) : "";
}

export function RaidPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { user } = useAuth();
  const [projects, setProjects] = useState<ProjectListItem[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState(id ?? "");
  const [summary, setSummary] = useState<RaidSummary | null>(null);
  const [items, setItems] = useState<RaidListItem[]>([]);
  const [selectedItemId, setSelectedItemId] = useState("");
  const [detail, setDetail] = useState<RaidDetail | null>(null);
  const [filters, setFilters] = useState({ type: "", status: "", priority: "", search: "" });
  const [form, setForm] = useState<CreateOrUpdateRaidItemRequest>(emptyForm);
  const [loading, setLoading] = useState(true);
  const [listLoading, setListLoading] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [editing, setEditing] = useState(false);
  const [creating, setCreating] = useState(false);
  const [busyAction, setBusyAction] = useState<"save" | "close" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<{ open: boolean; message: string; tone: "default" | "success" | "warning" }>({
    open: false,
    message: "",
    tone: "default"
  });

  const canManageRaid =
    user?.role === "PMO_ADMIN" || user?.role === "PROJECT_MANAGER" || user?.role === "PRODUCT_MANAGER" || user?.role === "TECH_LEAD";

  useEffect(() => {
    if (!toast.open) return undefined;
    const timer = window.setTimeout(() => setToast((current) => ({ ...current, open: false })), 2600);
    return () => window.clearTimeout(timer);
  }, [toast.open]);

  const loadProjects = useCallback(async () => {
    const data = await projectService.getProjects();
    setProjects(data);
    return data;
  }, []);

  const loadRaidList = useCallback(
    async (projectId: string, preferredItemId?: string) => {
      if (!projectId) {
        setItems([]);
        setSelectedItemId("");
        setDetail(null);
        setSummary(null);
        return;
      }

      setListLoading(true);
      setError(null);

      try {
        const [summaryData, listData] = await Promise.all([
          raidService.getRaidSummary(projectId),
          raidService.getProjectRaidItems(projectId, {
            type: filters.type || undefined,
            status: filters.status || undefined,
            priority: filters.priority || undefined,
            search: filters.search || undefined
          })
        ]);

        setSummary(summaryData);
        setItems(listData);

        const nextId = preferredItemId && listData.some((item) => item.id === preferredItemId) ? preferredItemId : listData[0]?.id ?? "";
        setSelectedItemId(nextId);
      } catch (requestError) {
        setError(getErrorMessage(requestError, "RAID listesi yüklenemedi."));
        setItems([]);
        setSummary(null);
      } finally {
        setListLoading(false);
      }
    },
    [filters.priority, filters.search, filters.status, filters.type]
  );

  const loadRaidDetail = useCallback(async (itemId: string) => {
    if (!itemId) {
      setDetail(null);
      return;
    }

    setDetailLoading(true);
    try {
      const data = await raidService.getRaidItem(itemId);
      setDetail(data);
      setForm({
        type: data.type,
        title: data.title,
        description: data.description,
        status: data.status,
        priority: data.priority ?? "",
        impact: data.impact ?? "",
        owner: data.owner,
        actionPlan: data.actionPlan,
        dueDate: toDateInput(data.dueDate),
        note: data.note
      });
    } catch (requestError) {
      setError(getErrorMessage(requestError, "RAID detayı yüklenemedi."));
      setDetail(null);
    } finally {
      setDetailLoading(false);
    }
  }, []);

  const loadPage = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const projectList = await loadProjects();
      const projectId = id ?? selectedProjectId || projectList[0]?.id || "";

      if (!projectId) {
        setLoading(false);
        return;
      }

      setSelectedProjectId(projectId);
      if (id !== projectId && !id) {
        navigate(`/projects/${projectId}/raid`, { replace: true });
      }

      await loadRaidList(projectId, selectedItemId);
    } catch (requestError) {
      setError(getErrorMessage(requestError, "RAID ekranı yüklenemedi."));
    } finally {
      setLoading(false);
    }
  }, [id, loadProjects, loadRaidList, navigate, selectedItemId, selectedProjectId]);

  useEffect(() => {
    void loadPage();
  }, [loadPage]);

  useEffect(() => {
    if (!selectedProjectId) return;
    void loadRaidList(selectedProjectId, selectedItemId);
  }, [filters, loadRaidList, selectedProjectId]);

  useEffect(() => {
    if (!selectedItemId || creating) return;
    void loadRaidDetail(selectedItemId);
  }, [creating, loadRaidDetail, selectedItemId]);

  const resetForm = useCallback(() => {
    setForm({
      ...emptyForm,
      owner: user?.fullName ?? ""
    });
  }, [user?.fullName]);

  const handleSelectProject = async (projectId: string) => {
    setSelectedProjectId(projectId);
    setCreating(false);
    setEditing(false);
    resetForm();
    navigate(`/projects/${projectId}/raid`);
  };

  const handleNewItem = () => {
    setCreating(true);
    setEditing(true);
    setSelectedItemId("");
    setDetail(null);
    resetForm();
  };

  const handleSave = async () => {
    if (!selectedProjectId) return;

    setBusyAction("save");
    setError(null);

    try {
      const payload = {
        ...form,
        dueDate: form.dueDate || null,
        priority: form.type === "Risk" || form.type === "Issue" ? form.priority || null : null,
        impact: form.type === "Risk" || form.type === "Issue" ? form.impact || null : null
      };

      const saved = creating
        ? await raidService.createRaidItem(selectedProjectId, payload)
        : await raidService.updateRaidItem(detail!.id, payload);

      setCreating(false);
      setEditing(false);
      setDetail(saved);
      await loadRaidList(selectedProjectId, saved.id);
      setToast({ open: true, message: creating ? "RAID kaydı oluşturuldu." : "RAID kaydı güncellendi.", tone: "success" });
    } catch (requestError) {
      setError(getErrorMessage(requestError, "RAID kaydı kaydedilemedi."));
      setToast({ open: true, message: "RAID kaydı başarısız.", tone: "warning" });
    } finally {
      setBusyAction(null);
    }
  };

  const handleCloseItem = async () => {
    if (!detail?.id) return;

    setBusyAction("close");
    setError(null);

    try {
      const closed = await raidService.closeRaidItem(detail.id, form.note);
      setDetail(closed);
      setEditing(false);
      await loadRaidList(selectedProjectId, detail.id);
      setToast({ open: true, message: "RAID kaydı kapatıldı.", tone: "success" });
    } catch (requestError) {
      setError(getErrorMessage(requestError, "RAID kaydı kapatılamadı."));
      setToast({ open: true, message: "Close işlemi başarısız.", tone: "warning" });
    } finally {
      setBusyAction(null);
    }
  };

  const rows = useMemo(
    () =>
      items.map((item) => [
        <Badge key={`${item.id}-type`} tone={item.badgeTone}>
          {getTypeLabel(item.type)}
        </Badge>,
        <button key={`${item.id}-title`} className={`table-link ${selectedItemId === item.id ? "active" : ""}`.trim()} type="button" onClick={() => setSelectedItemId(item.id)}>
          <strong>{item.title}</strong>
          <span className="stage-gate-muted">{item.owner}</span>
        </button>,
        <Badge key={`${item.id}-status`} tone={getStatusTone(item.status)}>
          {getStatusLabel(item.status)}
        </Badge>,
        <Badge key={`${item.id}-priority`} tone={getPriorityTone(item.priority)}>
          {item.priority ?? "-"}
        </Badge>,
        <Badge key={`${item.id}-impact`} tone={getPriorityTone(item.impact)}>
          {item.impact ?? "-"}
        </Badge>,
        <span key={`${item.id}-due`} className={item.dueDateText.includes("Gecikmiş") ? "overdue-text" : "mono-text"}>
          {item.dueDateText}
        </span>
      ]),
    [items, selectedItemId]
  );

  if (loading) {
    return <LoadingState message="RAID ekranı yükleniyor..." />;
  }

  if (error && !items.length && !creating) {
    return <ErrorState message={error} onRetry={() => void loadPage()} />;
  }

  return (
    <div className="placeholder-stack">
      <PageHeader
        title="RAID Log"
        subtitle="Risk, Issue, Assumption ve Dependency kayıtlarını proje bazlı izleyin."
        actions={
          <>
            <select className="inline-select" value={selectedProjectId} onChange={(event) => void handleSelectProject(event.target.value)}>
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </select>
            {canManageRaid ? (
              <button className="btn btn-primary" type="button" onClick={handleNewItem}>
                + Kayıt Ekle
              </button>
            ) : null}
          </>
        }
      />

      {summary ? (
        <div className="grid-4">
          <div className="stat-card blue">
            <div className="stat-label">Toplam Kayıt</div>
            <div className="stat-value">{summary.totalCount}</div>
            <div className="stat-note">Projedeki tüm RAID kalemleri</div>
          </div>
          <div className="stat-card yellow">
            <div className="stat-label">Açık Kayıt</div>
            <div className="stat-value">{summary.openCount}</div>
            <div className="stat-note">Aksiyon bekleyen kayıtlar</div>
          </div>
          <div className="stat-card red">
            <div className="stat-label">Kritik Risk</div>
            <div className="stat-value">{summary.criticalRiskCount}</div>
            <div className="stat-note">Anında yönetim takibi gerekir</div>
          </div>
          <div className="stat-card blue">
            <div className="stat-label">Overdue</div>
            <div className="stat-value">{summary.overdueCount}</div>
            <div className="stat-note">Termin tarihi geçmiş kayıtlar</div>
          </div>
        </div>
      ) : null}

      <div className="raid-grid">
        <Card title="RAID Listesi" meta="Filtreli canlı API verisi" bodyClassName="card-body-0">
          <div className="raid-filter-row">
            <select className="inline-select" value={filters.type} onChange={(event) => setFilters((current) => ({ ...current, type: event.target.value }))}>
              <option value="">Tüm Türler</option>
              {raidTypes.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
            <select className="inline-select" value={filters.status} onChange={(event) => setFilters((current) => ({ ...current, status: event.target.value }))}>
              <option value="">Tüm Durumlar</option>
              {raidStatuses.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
            <select className="inline-select" value={filters.priority} onChange={(event) => setFilters((current) => ({ ...current, priority: event.target.value }))}>
              <option value="">Tüm Öncelikler</option>
              {raidPriorities.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
            <input
              className="raid-search"
              placeholder="Başlık veya owner ara..."
              value={filters.search}
              onChange={(event) => setFilters((current) => ({ ...current, search: event.target.value }))}
            />
          </div>
          {listLoading ? (
            <LoadingState message="RAID kayıtları yükleniyor..." />
          ) : rows.length === 0 ? (
            <EmptyState title="Kayıt bulunamadı" subtitle="Filtreleri değiştirin veya yeni kayıt ekleyin." />
          ) : (
            <table className="tbl">
              <thead>
                <tr>
                  <th>Tür</th>
                  <th>Konu</th>
                  <th>Durum</th>
                  <th>Öncelik</th>
                  <th>Etki</th>
                  <th>Termin</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row, rowIndex) => (
                  <tr key={rowIndex}>{row.map((cell, cellIndex) => <td key={`${rowIndex}-${cellIndex}`}>{cell}</td>)}</tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>

        <Card title={creating ? "Yeni RAID Kaydı" : detail ? "RAID Detayı" : "Detay"} meta={creating ? "Yeni kayıt oluşturma" : detail?.title ?? "Seçili kayıt"} bodyClassName="card-body">
          {detailLoading ? (
            <LoadingState message="RAID detayı yükleniyor..." />
          ) : creating || editing ? (
            <div className="form-grid">
              <label className="form-field">
                <span>Tür</span>
                <select value={form.type} onChange={(event) => setForm({ ...form, type: event.target.value })}>
                  {raidTypes.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                <span>Durum</span>
                <select value={form.status} onChange={(event) => setForm({ ...form, status: event.target.value })}>
                  {raidStatuses.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </label>
              <label className="form-field form-field-full">
                <span>Başlık</span>
                <input value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} />
              </label>
              <label className="form-field form-field-full">
                <span>Açıklama</span>
                <textarea value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} />
              </label>
              <label className="form-field">
                <span>Öncelik</span>
                <select value={form.priority ?? ""} onChange={(event) => setForm({ ...form, priority: event.target.value })}>
                  <option value="">Boş</option>
                  {raidPriorities.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                <span>Etki</span>
                <select value={form.impact ?? ""} onChange={(event) => setForm({ ...form, impact: event.target.value })}>
                  <option value="">Boş</option>
                  {raidImpacts.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              </label>
              <label className="form-field">
                <span>Owner</span>
                <input value={form.owner} onChange={(event) => setForm({ ...form, owner: event.target.value })} />
              </label>
              <label className="form-field">
                <span>Due Date</span>
                <input type="date" value={form.dueDate ?? ""} onChange={(event) => setForm({ ...form, dueDate: event.target.value })} />
              </label>
              <label className="form-field form-field-full">
                <span>Aksiyon Planı</span>
                <textarea value={form.actionPlan} onChange={(event) => setForm({ ...form, actionPlan: event.target.value })} />
              </label>
              <label className="form-field form-field-full">
                <span>Not</span>
                <textarea value={form.note} onChange={(event) => setForm({ ...form, note: event.target.value })} />
              </label>
              {error ? (
                <div className="form-field-full">
                  <div className="alert alert-warning">
                    <span className="alert-icon">!</span>
                    <span>{error}</span>
                  </div>
                </div>
              ) : null}
              <div className="form-actions form-field-full">
                <button
                  className="btn btn-secondary"
                  type="button"
                  onClick={() => {
                    setCreating(false);
                    setEditing(false);
                    if (detail) {
                      setForm({
                        type: detail.type,
                        title: detail.title,
                        description: detail.description,
                        status: detail.status,
                        priority: detail.priority ?? "",
                        impact: detail.impact ?? "",
                        owner: detail.owner,
                        actionPlan: detail.actionPlan,
                        dueDate: toDateInput(detail.dueDate),
                        note: detail.note
                      });
                    }
                  }}
                >
                  İptal
                </button>
                <button className="btn btn-primary" type="button" disabled={busyAction === "save"} onClick={() => void handleSave()}>
                  {busyAction === "save" ? "Kaydediliyor..." : creating ? "Kaydı Oluştur" : "Güncelle"}
                </button>
              </div>
            </div>
          ) : detail ? (
            <div className="stage-gate-detail">
              <div className="raid-badge-row">
                <Badge tone={detail.type === "Risk" ? "red" : detail.type === "Issue" ? "yellow" : detail.type === "Assumption" ? "blue" : "purple"}>
                  {getTypeLabel(detail.type)}
                </Badge>
                <Badge tone={getStatusTone(detail.status)}>{getStatusLabel(detail.status)}</Badge>
                {detail.priority ? <Badge tone={getPriorityTone(detail.priority)}>{detail.priority}</Badge> : null}
                {detail.impact ? <Badge tone={getPriorityTone(detail.impact)}>{detail.impact}</Badge> : null}
              </div>
              <div className="detail-list">
                <div className="detail-row">
                  <span>Başlık</span>
                  <strong>{detail.title}</strong>
                </div>
                <div className="detail-row">
                  <span>Owner</span>
                  <strong>{detail.owner}</strong>
                </div>
                <div className="detail-row">
                  <span>Due Date</span>
                  <strong className={detail.dueDateText.includes("Gecikmiş") ? "overdue-text" : ""}>{detail.dueDateText}</strong>
                </div>
                <div className="detail-row">
                  <span>Resolved</span>
                  <strong>{detail.resolvedDateText ?? "-"}</strong>
                </div>
              </div>
              <div className="project-rich-text">{detail.description}</div>
              <div className="project-rich-sub">{detail.actionPlan}</div>
              {detail.note ? <div className="project-rich-sub">{detail.note}</div> : null}
              {canManageRaid && detail.canEdit ? (
                <div className="form-actions" style={{ marginTop: 0 }}>
                  <button className="btn btn-secondary" type="button" onClick={() => setEditing(true)}>
                    Düzenle
                  </button>
                  {detail.canClose ? (
                    <button className="btn btn-danger" type="button" disabled={busyAction === "close"} onClick={() => void handleCloseItem()}>
                      {busyAction === "close" ? "Kapatılıyor..." : "Kaydı Kapat"}
                    </button>
                  ) : null}
                </div>
              ) : null}
            </div>
          ) : (
            <EmptyState title="RAID detayı seçilmedi" subtitle="Soldaki listeden bir kayıt seçin." />
          )}
        </Card>
      </div>

      <Toast open={toast.open} message={toast.message} tone={toast.tone} />
    </div>
  );
}
