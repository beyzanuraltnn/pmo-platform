import { useCallback, useEffect, useMemo, useState } from "react";
import { projectService } from "../api/services/projectService";
import type { DashboardSummary } from "../api/types";
import { EmptyState } from "../components/feedback/EmptyState";
import { ErrorState } from "../components/feedback/ErrorState";
import { LoadingState } from "../components/feedback/LoadingState";
import { Badge } from "../components/ui/Badge";
import { Card } from "../components/ui/Card";
import { PageHeader } from "../components/ui/PageHeader";
import { StatCard } from "../components/ui/StatCard";
import { Table } from "../components/ui/Table";

export function DashboardPage() {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchSummary = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const data = await projectService.getDashboardSummary();
      setSummary(data);
    } catch {
      setSummary(null);
      setError("Dashboard özeti yüklenemedi.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchSummary();
  }, [fetchSummary]);

  const isEmpty = useMemo(() => {
    return !summary || summary.summaryCards.length === 0;
  }, [summary]);

  return (
    <>
      <PageHeader
        title="Haftalık Yönetim Panosu"
        subtitle="WEEKLY EXECUTIVE DASHBOARD · 10 Mart 2026 · Haftalık Otomatik Güncelleme"
        actions={
          <>
            <button className="btn btn-secondary" type="button">
              ↓ PDF
            </button>
            <button className="btn btn-primary" type="button">
              📧 Üst Yönetime Gönder
            </button>
          </>
        }
      />

      {loading ? (
        <Card title="Dashboard Özeti">
          <LoadingState message="Dashboard verileri yükleniyor..." />
        </Card>
      ) : error ? (
        <Card title="Dashboard Özeti">
          <ErrorState message={error} onRetry={() => void fetchSummary()} />
        </Card>
      ) : isEmpty ? (
        <Card title="Dashboard Özeti">
          <EmptyState title="Dashboard verisi bulunamadı" subtitle="API özet verisi henüz dönmedi." />
        </Card>
      ) : (
        <>
          <div className="grid-4">
            {summary.summaryCards.map((stat) => (
              <StatCard key={stat.label} label={stat.label} value={String(stat.value)} note={stat.note} tone={stat.tone} />
            ))}
          </div>

          <Card title="3. Aktif Projeler" meta="Haftalık RAG durumu özeti" bodyClassName="card-body-0">
            {summary.activeProjects.length === 0 ? (
              <EmptyState title="Aktif proje bulunamadı" subtitle="Dashboard özeti aktif proje döndürmedi." />
            ) : (
              <Table
                columns={["Proje", "Proje Türü", "PM", "Aşama", "Durum", "Go-Live", "Risk", ""]}
                rows={summary.activeProjects.map((project) => [
                  <strong key={`${project.name}-name`}>{project.name}</strong>,
                  <Badge key={`${project.name}-type`} tone={project.type === "Entegrasyon" ? "blue" : project.type === "Ürün" ? "purple" : "red"}>
                    {project.type}
                  </Badge>,
                  project.projectManager,
                  <Badge key={`${project.name}-stage`} tone={project.stage === "Analiz" ? "gray" : project.stage === "Development" ? "yellow" : "red"}>
                    {project.stage}
                  </Badge>,
                  <span className="rag" key={`${project.name}-rag`}>
                    <span className={`rag-dot ${project.ragStatus}`} />
                    {project.ragStatus.charAt(0).toUpperCase() + project.ragStatus.slice(1)}
                  </span>,
                  <span key={`${project.name}-date`} style={{ fontFamily: "var(--mono)", fontSize: 12 }}>
                    {project.goLiveDateText}
                  </span>,
                  <Badge key={`${project.name}-risk`} tone={project.riskLevel === "Düşük" ? "green" : project.riskLevel === "Orta" ? "yellow" : "red"}>
                    {project.riskLevel}
                  </Badge>,
                  <button className="btn btn-secondary btn-sm row-actions" type="button" key={`${project.name}-button`}>
                    → Detay
                  </button>
                ])}
              />
            )}
          </Card>

          <div className="grid-2">
            <Card title="4. Bu Hafta Go-Live Planlanan" bodyClassName="card-body-0">
              {summary.weeklyGoLives.length === 0 ? (
                <EmptyState title="Bu hafta go-live kaydı yok" />
              ) : (
                <Table
                  columns={["Proje", "Tarih", "Durum", "Not"]}
                  rows={summary.weeklyGoLives.map((row) => [
                    <strong key={`${row.projectName}-name`}>{row.projectName}</strong>,
                    <span key={`${row.projectName}-date`} style={{ fontFamily: "var(--mono)", fontSize: 11 }}>
                      {row.dateText}
                    </span>,
                    <Badge key={`${row.projectName}-status`} tone="green">
                      {row.statusText}
                    </Badge>,
                    <span key={`${row.projectName}-note`} style={{ fontSize: 12, color: "var(--ink3)" }}>
                      {row.note}
                    </span>
                  ])}
                />
              )}
            </Card>

            <Card title="6. Geciken Milestone'lar" bodyClassName="card-body-0">
              {summary.delayedMilestones.length === 0 ? (
                <EmptyState title="Geciken milestone yok" />
              ) : (
                <Table
                  columns={["Proje", "Milestone", "Planlanan", "Yeni Hedef"]}
                  rows={summary.delayedMilestones.map((row) => [
                    <strong key={`${row.projectName}-name`}>{row.projectName}</strong>,
                    row.milestoneName,
                    <span key={`${row.projectName}-planned`} style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--red)" }}>
                      {row.plannedDateText}
                    </span>,
                    <span key={`${row.projectName}-new`} style={{ fontFamily: "var(--mono)", fontSize: 11 }}>
                      {row.newTargetDateText}
                    </span>
                  ])}
                />
              )}
            </Card>
          </div>

          <div className="grid-2">
            <Card title="5. Kritik Riskler" meta="RAID Log'dan otomatik beslenir" bodyClassName="card-body-0">
              {summary.criticalRisks.length === 0 ? (
                <EmptyState title="Kritik risk bulunamadı" />
              ) : (
                <Table
                  columns={["Proje", "Risk", "Etki", "Aksiyon"]}
                  rows={summary.criticalRisks.map((row) => [
                    <strong key={`${row.projectName}-name`}>{row.projectName}</strong>,
                    row.riskText,
                    <Badge key={`${row.projectName}-impact`} tone={row.impactLevel === "Yüksek" ? "red" : "yellow"}>
                      {row.impactLevel}
                    </Badge>,
                    <span key={`${row.projectName}-action`} style={{ fontSize: 12 }}>
                      {row.actionText}
                    </span>
                  ])}
                />
              )}
            </Card>

            <Card title="8. Yönetim Aksiyon Gerektiren Konular">
              {summary.actionItems.length === 0 ? (
                <EmptyState title="Aksiyon gerektiren kayıt yok" />
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {summary.actionItems.map((item) => (
                    <div
                      key={item.title}
                      style={{
                        padding: "12px 14px",
                        borderRadius: 8,
                        borderLeft: `3px solid var(--${item.tone})`,
                        background: `var(--${item.tone}-light)`
                      }}
                    >
                      <div style={{ fontSize: 13, fontWeight: 600, color: `var(--${item.tone})`, marginBottom: 3 }}>{item.title}</div>
                      <div style={{ fontSize: 12, color: "var(--ink2)" }}>{item.body}</div>
                      <button className={`btn btn-${item.tone === "red" ? "danger" : "warning"} btn-sm`} style={{ marginTop: 8 }} type="button">
                        {item.buttonText}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        </>
      )}
    </>
  );
}
