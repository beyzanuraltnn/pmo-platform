import type { ReactNode } from "react";
import type { ComponentType, SVGProps } from "react";
import {
  ActiveProjectsIcon,
  PlannedProjectsIcon,
  CheckIcon,
  ClockIcon,
  CompletedProjectsIcon,
  DashboardIcon,
  DocumentIcon,
  TrendIcon,
  UserIcon,
  WarningIcon
} from "../components/icons/NavIcons";

type IconComponent = ComponentType<SVGProps<SVGSVGElement>>;

export type NavigationItem = {
  label: string;
  path: string;
  icon: IconComponent;
  badge?: {
    text: string;
    tone: "yellow" | "blue" | "green" | "red";
  };
};

export type NavigationGroup = {
  label: string;
  items: NavigationItem[];
};

export type PageMeta = {
  title: string;
  topbarMeta: string;
};

export const navigationGroups: NavigationGroup[] = [
  {
    label: "Genel Bakış",
    items: [{ label: "Haftalık Dashboard", path: "/dashboard", icon: DashboardIcon }]
  },
  {
    label: "Proje Portföyü",
    items: [
      { label: "Aktif Projeler", path: "/projects/active", icon: ActiveProjectsIcon, badge: { text: "3", tone: "yellow" } },
      { label: "Planlanan Projeler", path: "/projects/planned", icon: PlannedProjectsIcon, badge: { text: "2", tone: "blue" } },
      { label: "Tamamlanan Projeler", path: "/projects/completed", icon: CompletedProjectsIcon, badge: { text: "2", tone: "green" } }
    ]
  },
  {
    label: "Proje Araçları",
    items: [
      { label: "Project Charter", path: "/charter", icon: DocumentIcon },
      { label: "Q Plan & Gantt", path: "/qplan", icon: ClockIcon },
      { label: "RAID Log", path: "/raid", icon: WarningIcon, badge: { text: "5", tone: "red" } },
      { label: "Stage Gate", path: "/stage-gate", icon: CheckIcon, badge: { text: "2", tone: "yellow" } }
    ]
  },
  {
    label: "Analitik & Raporlama",
    items: [
      { label: "KPI Takibi", path: "/kpi", icon: TrendIcon },
      { label: "Proje Kapanış Raporu", path: "/closure", icon: CheckIcon }
    ]
  },
  {
    label: "Sistem",
    items: [{ label: "Kullanıcı Yönetimi", path: "/users", icon: UserIcon }]
  }
];

export const pageMetaMap: Record<string, PageMeta> = {
  "/dashboard": { title: "Haftalık Yönetim Panosu", topbarMeta: "Haftanın Raporu — 10 Mart 2026" },
  "/projects/active": { title: "Aktif Projeler", topbarMeta: "Portföy Görünümü — 10 Mart 2026" },
  "/projects/planned": { title: "Planlanan Projeler", topbarMeta: "Planlama Havuzu — 10 Mart 2026" },
  "/projects/completed": { title: "Tamamlanan Projeler", topbarMeta: "Kapanış Arşivi — 10 Mart 2026" },
  "/charter": { title: "Project Charter", topbarMeta: "Charter Yönetimi — Canlı Veri" },
  "/qplan": { title: "Q Plan & Gantt Chart", topbarMeta: "Portföy Planı — 2026" },
  "/raid": { title: "RAID Log", topbarMeta: "Risk ve Issue Takibi — Canlı Veri" },
  "/stage-gate": { title: "Stage Gate Checklist", topbarMeta: "Onay Takibi — 10 Mart 2026" },
  "/kpi": { title: "KPI Takibi", topbarMeta: "Metrik Özeti — 10 Mart 2026" },
  "/closure": { title: "Proje Kapanış Raporu", topbarMeta: "Kapanış Süreci — 10 Mart 2026" },
  "/users": { title: "Kullanıcı Yönetimi", topbarMeta: "Rol Yönetimi — 10 Mart 2026" }
};

export const notifications = [
  {
    title: "📊 Haftalık Dashboard Hazır",
    body: "CTO ve PMO Admin için haftalık rapor oluşturuldu. E-posta göndermeye hazır.",
    time: "5 dk önce",
    unread: true
  },
  {
    title: "Gate 4 Onayı Bekliyor",
    body: "Regülasyon Uyum Projesi için QA onayı 8 gündür bekliyor.",
    time: "25 dk önce",
    unread: true
  },
  {
    title: "Yeni Risk Eskalasyonu",
    body: "Mobil Cüzdan v2 için dış paydaş bağımlılığı yüksek risk olarak işaretlendi.",
    time: "1 saat önce",
    unread: false
  }
];

export const dashboardStats = [
  { label: "Aktif Projeler", value: "3", note: "Toplam portföy", tone: "blue" as const },
  { label: "Green", value: "1", note: "Planda ilerliyor", tone: "green" as const },
  { label: "Yellow", value: "1", note: "Risk/gecikme ihtimali", tone: "yellow" as const },
  { label: "Red", value: "1", note: "Kritik risk", tone: "red" as const }
];

export const dashboardProjects = [
  ["BKM Entegrasyon", "Entegrasyon", "A. Yılmaz", "Analiz", "green", "Q2 2026", "Düşük"],
  ["Mobil Cüzdan v2", "Ürün", "S. Kaya", "Development", "yellow", "Q2 2026", "Orta"],
  ["Regülasyon Uyum", "Regülasyon", "M. Demir", "Test", "red", "Gecikti", "Yüksek"]
] as const;

export const goLiveRows = [["Kart Servisi Fix", "12 Mar", "Hazır", "Tüm onaylar tamam"]] as const;

export const delayedMilestones = [
  ["Mobil Cüzdan v2", "Dev Tamamlanması", "1 Mar", "15 Mar"],
  ["Regülasyon Uyum", "Test Tamamlanması", "28 Şub", "20 Mar"]
] as const;

export const criticalRisks = [
  ["Regülasyon Uyum", "UAT reject oranı %35", "Yüksek", "QA ekibi genişletilecek"],
  ["Mobil Cüzdan v2", "Finekra API hâlâ gelmedi", "Orta", "Satın alma eskalasyonu"]
] as const;

export const actionItems = [
  {
    title: "Regülasyon Uyum — Gate 4 onayı 8 gündür bekliyor",
    body: "Onay bekleyen: QA (Z. Akın) · UAT reject oranı hedefin üzerinde.",
    button: "→ Gate'e Git",
    tone: "red"
  },
  {
    title: "Mobil Cüzdan v2 — Dış paydaş bağımlılığı",
    body: "Finekra API dokümanı 2 haftadır bekleniyor. Go-live'ı tehdit ediyor.",
    button: "→ RAID'e Git",
    tone: "yellow"
  }
] as const;

export type ModulePageData = {
  title: string;
  subtitle: string;
  action?: ReactNode;
  alert?: {
    icon: string;
    className: string;
    text: ReactNode;
  };
  cardTitle: string;
  cardMeta?: string;
  columns: string[];
  rows: ReactNode[][];
};

export const modulePages: Record<string, ModulePageData> = {
  active: {
    title: "Aktif Projeler",
    subtitle: "Aktif olarak yürütülen projelerin merkezi görünümü",
    action: (
      <>
        <select className="inline-select">
          <option>Tüm Projeler</option>
          <option>Green</option>
          <option>Yellow</option>
          <option>Red</option>
        </select>
        <button className="btn btn-primary">+ Proje Ekle</button>
      </>
    ),
    cardTitle: "Aktif Proje Listesi",
    cardMeta: "3 aktif proje · Haftalık güncelleme gerekir",
    columns: ["Proje", "Tür", "PM", "Aşama", "Durum", "Go-Live", "Risk"],
    rows: [
      ["BKM Entegrasyon", "Entegrasyon", "A. Yılmaz", "Analiz", "Green", "Q2 2026", "Düşük"],
      ["Mobil Cüzdan v2", "Ürün", "S. Kaya", "Development", "Yellow", "Q2 2026", "Orta"],
      ["Regülasyon Uyum", "Regülasyon", "M. Demir", "Test", "Red", "Gecikti", "Yüksek"]
    ]
  },
  planned: {
    title: "Planlanan Projeler",
    subtitle: "Henüz başlatılmamış, planlama aşamasındaki projeler",
    action: <button className="btn btn-primary">+ Planlanan Proje Ekle</button>,
    alert: {
      icon: "ℹ",
      className: "alert alert-info",
      text: (
        <>
          Bu sayfadaki projeler aktif geliştirme sürecine girmemiştir. Charter onayı alınmadan proje aktifleşemez.
          <strong> (IK-01)</strong>
        </>
      )
    },
    cardTitle: "Planlanan Proje Listesi",
    cardMeta: "2 proje planlama aşamasında",
    columns: ["Proje", "Tür", "Öncelik", "Planlanan Başlangıç", "Beklenen Go-Live", "Not"],
    rows: [
      ["Fraud Detection v3", "Ürün", "Yüksek", "Q2 2026", "Q4 2026", "Bütçe onayı bekleniyor"],
      ["Admin Panel Yenileme", "Ürün", "Orta", "Q3 2026", "Q4 2026", "—"]
    ]
  },
  completed: {
    title: "Tamamlanan Projeler",
    subtitle: "Resmi olarak kapatılmış proje arşivi",
    cardTitle: "Tamamlanan Proje Arşivi",
    cardMeta: "2 proje kapatıldı",
    columns: ["Proje", "Tür", "Go-Live Tarihi", "PM", "SV (gün)", "UAT %"],
    rows: [
      ["Kart Servisi Entegrasyon", "Entegrasyon", "Jan 2026", "E. Çelik", "+2", "94%"],
      ["Ödeme Altyapısı", "Altyapı", "Nov 2025", "B. Arslan", "+7", "88%"]
    ]
  },
  charter: {
    title: "Project Charter",
    subtitle: "Projenin resmi başlatma belgesi — Charter onayı olmadan proje aktif olamaz (IK-01)",
    action: (
      <>
        <select className="inline-select">
          <option>BKM Entegrasyon</option>
          <option>Mobil Cüzdan v2</option>
          <option>Regülasyon Uyum</option>
        </select>
        <button className="btn btn-secondary">Taslak Kaydet</button>
        <button className="btn btn-primary">Onaya Gönder →</button>
      </>
    ),
    alert: {
      icon: "⚠",
      className: "alert alert-warning",
      text: (
        <>
          <strong>İş Kuralı IK-01:</strong> Charter PMO ve Ürün Yöneticisi onayı alınmadan proje Aktif durumuna geçirilemez.
        </>
      )
    },
    cardTitle: "1. Proje Özeti",
    cardMeta: "Gate 1 başlangıç iskeleti",
    columns: ["Alan", "Demo Değer"],
    rows: [
      ["Proje Adı", "BKM Entegrasyon"],
      ["Proje Türü", "Entegrasyon"],
      ["Hedef Canlı Tarihi", "2026-06-30"]
    ]
  },
  qplan: {
    title: "Q Plan & Gantt Chart",
    subtitle: "Çeyrek bazlı görsel planlama · PRD M6 Modülü",
    action: (
      <>
        <select className="inline-select">
          <option>2026</option>
        </select>
        <button className="btn btn-secondary">📊 Gantt Chart</button>
        <button className="btn btn-primary">+ Projeyi Q Plana Ekle</button>
      </>
    ),
    cardTitle: "Q Plan — 2026 Yıllık Görünüm",
    cardMeta: "Projeler çeyrekler arasında sürükle-bırak ile taşınabilir",
    columns: ["Çeyrek", "Projeler"],
    rows: [
      ["Q1", "Regülasyon Uyum"],
      ["Q2", "Mobil Cüzdan v2 · BKM Entegrasyon"],
      ["Q3", "API Gateway Modernizasyonu"],
      ["Q4", "—"]
    ]
  },
  raid: {
    title: "RAID Log",
    subtitle: "Risk · Assumption · Issue · Dependency — Haftalık güncellenmeli",
    action: <button className="btn btn-primary">+ Kayıt Ekle</button>,
    cardTitle: "RAID Kayıtları",
    cardMeta: "Demo veri ile statik görünüm",
    columns: ["Tür", "Konu", "Etki", "Durum"],
    rows: [
      ["Risk", "Finekra API bekleniyor", "Yüksek", "Açık"],
      ["Issue", "UAT reject oranı arttı", "Yüksek", "Açık"],
      ["Dependency", "BKM sertifikasyon slotu", "Orta", "Takipte"]
    ]
  },
  stageGate: {
    title: "Stage Gate Checklist",
    subtitle: "Kanıt tabanlı onay sistemi — Gate onayı olmadan üst aşama açılmaz (IK-02/03)",
    cardTitle: "Gate Akışı",
    cardMeta: "Checklist + kanıt + onay panelleri sonraki adımda bağlanacak",
    columns: ["Gate", "Durum", "Zorunlu Kanıt", "Bekleyen"],
    rows: [
      ["Gate 1", "Tamamlandı", "Charter PDF", "—"],
      ["Gate 2", "Bekliyor", "Gereksinim dokümanı, Wireframe", "TECH_LEAD"],
      ["Gate 3", "Kilitli", "Code review raporu, Release notları", "—"]
    ]
  },
  kpi: {
    title: "KPI Takibi",
    subtitle: "Proje performans metrikleri — KPI'lar otomatik hesaplanır (PRD M9)",
    cardTitle: "KPI Özeti",
    cardMeta: "Formül ve canlı hesaplar sonraki adımda bağlanacak",
    columns: ["KPI", "Değer", "Periyot"],
    rows: [
      ["Schedule Variance", "+4 gün", "Haftalık"],
      ["Milestone Gecikme Oranı", "%18", "Haftalık"],
      ["Yüksek Risk Oranı", "%22", "Haftalık"]
    ]
  },
  closure: {
    title: "Proje Kapanış Raporu",
    subtitle: "Kapanış raporu tamamlanmadan proje resmi olarak kapatılamaz — Gate 6",
    cardTitle: "Kapanış Özeti",
    cardMeta: "Lessons learned ve performans notu alanları sonraki adımda detaylandırılacak",
    columns: ["Alan", "Demo Değer"],
    rows: [
      ["Proje", "Kart Servisi Entegrasyon"],
      ["Kapanış Tarihi", "15 Jan 2026"],
      ["Lessons Learned", "İlk planlama doğruluğu kritik"]
    ]
  },
  users: {
    title: "Kullanıcı Yönetimi",
    subtitle: "7 farklı rol · PRD M12 · Sadece PMO_ADMIN erişebilir",
    action: <button className="btn btn-primary">+ Kullanıcı Davet Et</button>,
    cardTitle: "Kullanıcı Listesi",
    cardMeta: "Rol atama aksiyonları sonraki adımda eklenecek",
    columns: ["Ad Soyad", "E-posta", "Rol", "Durum"],
    rows: [
      ["Pelin Yılmaz", "admin@pmo.local", "PMO_ADMIN", "Aktif"],
      ["Emre Kaya", "pm@pmo.local", "PROJECT_MANAGER", "Aktif"],
      ["Zeynep Akın", "qa@pmo.local", "QA", "Aktif"]
    ]
  }
};
