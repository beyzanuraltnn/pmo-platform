export const AUTH_TOKEN_KEY = "pmo.auth.token";
export const AUTH_USER_KEY = "pmo.auth.user";

type StorageMode = "local" | "session";

function getStorage(): Storage {
  const mode = import.meta.env.VITE_AUTH_STORAGE === "session" ? "session" : "local";
  return mode === "session" ? window.sessionStorage : window.localStorage;
}

export function getToken() {
  return getStorage().getItem(AUTH_TOKEN_KEY);
}

export function setToken(token: string) {
  getStorage().setItem(AUTH_TOKEN_KEY, token);
}

export function clearToken() {
  getStorage().removeItem(AUTH_TOKEN_KEY);
}

export type AuthUser = {
  id?: string;
  fullName?: string;
  email?: string;
  role?: string;
};

export function getStoredUser(): AuthUser | null {
  const raw = getStorage().getItem(AUTH_USER_KEY);

  if (!raw) {
    return null;
  }

  try {
    return JSON.parse(raw) as AuthUser;
  } catch {
    return null;
  }
}

export function setStoredUser(user: AuthUser) {
  getStorage().setItem(AUTH_USER_KEY, JSON.stringify(user));
}

export function clearStoredUser() {
  getStorage().removeItem(AUTH_USER_KEY);
}

export function clearAuthStorage() {
  clearToken();
  clearStoredUser();
}
