import { createContext, useContext, useMemo, useState } from "react";
import type { PropsWithChildren } from "react";
import { authService } from "../api/services/authService";
import type { LoginRequest } from "../api/types";
import {
  clearAuthStorage,
  getStoredUser,
  getToken,
  setStoredUser,
  setToken,
  type AuthUser
} from "./authStorage";

type AuthContextValue = {
  isAuthenticated: boolean;
  user: AuthUser | null;
  login: (payload: LoginRequest) => Promise<void>;
  logout: () => void;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: PropsWithChildren) {
  const [token, setTokenState] = useState<string | null>(() => getToken());
  const [user, setUser] = useState<AuthUser | null>(() => getStoredUser());

  const value = useMemo<AuthContextValue>(
    () => ({
      isAuthenticated: Boolean(token),
      user,
      async login(payload) {
        const result = await authService.login(payload);

        setToken(result.token);
        setTokenState(result.token);

        const nextUser = result.user ?? {
          email: payload.email,
          fullName: payload.email,
          role: "PMO_ADMIN"
        };

        setStoredUser(nextUser);
        setUser(nextUser);
      },
      logout() {
        clearAuthStorage();
        setTokenState(null);
        setUser(null);
      }
    }),
    [token, user]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error("useAuth must be used within AuthProvider.");
  }

  return context;
}
