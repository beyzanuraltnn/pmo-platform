import { Navigate, createBrowserRouter } from "react-router-dom";
import { AppLayout } from "../layouts/AppLayout";
import { PrivateRoute } from "../auth/PrivateRoute";
import { modulePages } from "../data/demo";
import { DashboardPage } from "../pages/DashboardPage";
import { LoginPage } from "../pages/LoginPage";
import { ModulePage } from "../pages/ModulePage";
import { RaidPage } from "../pages/RaidPage";
import { StageGatePage } from "../pages/StageGatePage";
import { ProjectCharterPage } from "../pages/projects/ProjectCharterPage";
import { ProjectDetailPage } from "../pages/projects/ProjectDetailPage";
import { ProjectsListPage } from "../pages/projects/ProjectsListPage";

export const router = createBrowserRouter([
  {
    path: "/login",
    element: <LoginPage />
  },
  {
    path: "/",
    element: <PrivateRoute />,
    children: [
      {
        element: <AppLayout />,
        children: [
          { index: true, element: <Navigate to="/dashboard" replace /> },
          { path: "dashboard", element: <DashboardPage /> },
          { path: "projects/new", element: <ProjectDetailPage /> },
          { path: "projects/:id", element: <ProjectDetailPage /> },
          { path: "projects/:id/charter", element: <ProjectCharterPage /> },
          { path: "projects/:id/raid", element: <RaidPage /> },
          { path: "projects/active", element: <ProjectsListPage variant="active" /> },
          { path: "projects/planned", element: <ProjectsListPage variant="planned" /> },
          { path: "projects/completed", element: <ProjectsListPage variant="completed" /> },
          { path: "charter", element: <ProjectCharterPage /> },
          { path: "qplan", element: <ModulePage page={modulePages.qplan} /> },
          { path: "raid", element: <RaidPage /> },
          { path: "stage-gate", element: <StageGatePage /> },
          { path: "kpi", element: <ModulePage page={modulePages.kpi} /> },
          { path: "closure", element: <ModulePage page={modulePages.closure} /> },
          { path: "users", element: <ModulePage page={modulePages.users} /> }
        ]
      }
    ]
  }
]);
