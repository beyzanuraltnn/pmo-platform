import { useCallback, useEffect, useMemo, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { notificationService } from "../api/services/notificationService";
import type { NotificationItem } from "../api/types";
import { EmptyState } from "../components/feedback/EmptyState";
import { ErrorState } from "../components/feedback/ErrorState";
import { LoadingState } from "../components/feedback/LoadingState";
import { Sidebar } from "../components/ui/Sidebar";
import { Topbar } from "../components/ui/Topbar";
import { Toast } from "../components/ui/Toast";
import { Modal } from "../components/ui/Modal";
import { useAuth } from "../auth/AuthContext";
import { pageMetaMap } from "../data/demo";

export function AppLayout() {
  const location = useLocation();
  const { logout } = useAuth();
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [notificationsLoading, setNotificationsLoading] = useState(false);
  const [notificationsError, setNotificationsError] = useState<string | null>(null);

  const pageMeta = useMemo(() => {
    if (pageMetaMap[location.pathname]) {
      return pageMetaMap[location.pathname];
    }

    if (/^\/projects\/[^/]+\/charter$/.test(location.pathname) || location.pathname === "/charter") {
      return { title: "Project Charter", topbarMeta: "Charter Yönetimi — Canlı Veri" };
    }

    if (/^\/projects\/[^/]+\/raid$/.test(location.pathname) || location.pathname === "/raid") {
      return { title: "RAID Log", topbarMeta: "Risk ve Issue Takibi — Canlı Veri" };
    }

    if (/^\/projects\/(new|[^/]+)$/.test(location.pathname)) {
      return { title: "Proje Detayı", topbarMeta: "Proje Yaşam Döngüsü — Canlı Veri" };
    }

    return pageMetaMap["/dashboard"];
  }, [location.pathname]);

  const unreadCount = useMemo(() => notifications.filter((notification) => notification.unread).length, [notifications]);

  const fetchNotifications = useCallback(async () => {
    setNotificationsLoading(true);
    setNotificationsError(null);

    try {
      const data = await notificationService.getNotifications();
      setNotifications(data);
    } catch {
      setNotifications([]);
      setNotificationsError("Bildirimler yüklenemedi.");
    } finally {
      setNotificationsLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchNotifications();
  }, [fetchNotifications]);

  useEffect(() => {
    if (notificationsOpen) {
      void fetchNotifications();
    }
  }, [fetchNotifications, notificationsOpen]);

  const handleLogout = () => {
    logout();
    window.location.href = "/login";
  };

  return (
    <>
      <Sidebar />
      <div className="main">
        <Topbar
          title={pageMeta.title}
          meta={pageMeta.topbarMeta}
          unreadCount={unreadCount}
          onToggleNotifications={() => setNotificationsOpen((current) => !current)}
          onLogout={handleLogout}
        />

        <div className="content">
          <Outlet />
        </div>
      </div>

      <div className={`notif-panel${notificationsOpen ? " open" : ""}`}>
        <div className="notif-panel-header">
          <div className="card-title">Bildirimler</div>
          <button className="btn btn-secondary btn-sm" type="button" onClick={() => setNotificationsOpen(false)}>
            Kapat
          </button>
        </div>
        {notificationsLoading ? (
          <LoadingState message="Bildirimler yükleniyor..." />
        ) : notificationsError ? (
          <ErrorState message={notificationsError} onRetry={() => void fetchNotifications()} />
        ) : notifications.length === 0 ? (
          <EmptyState title="Yeni bildiriminiz yok" subtitle="Uygulama içi bildirimler burada listelenecek." />
        ) : (
          notifications.map((notification) => (
            <div className={`notif-item${notification.unread ? " unread" : ""}`} key={`${notification.id ?? notification.title}-${notification.time}`}>
              <div className="notif-title">{notification.title}</div>
              <div className="notif-body">{notification.body}</div>
              <div className="notif-time">{notification.time}</div>
            </div>
          ))
        )}
      </div>

      <Toast open={false} message="Rapor CTO ve PMO Admin'e gönderildi" tone="success" />
      <Modal open={false} title="Yeni Aktif Proje Ekle" size="sm">
        Bu aşamada yalnızca layout ve statik bileşen iskeleti oluşturuldu.
      </Modal>
    </>
  );
}
