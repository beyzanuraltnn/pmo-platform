using PMO.Platform.Domain.Entities;

namespace PMO.Platform.Application.Common.Interfaces.Security;

public interface IJwtTokenGenerator
{
    string GenerateToken(User user, IReadOnlyList<string> roles);
}
